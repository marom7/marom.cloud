# פלט Windows x64

`windows-x64/` הוא פלט Release מסוג **framework-dependent**, שנוצר מאותו קוד מקור שבחבילה. נבנה בהצלחה ב־SDK 8.0.428; לא הורץ על Windows כאן.

נדרש **ASP.NET Core Runtime 8 x64** תואם, הכולל את שני shared frameworks. העתק את כל התיקייה למיקום פיילוט חדש וניתן לכתיבה; אל תעתיק מעל הייצור.

```powershell
cd windows-x64
.\Digi67.Engine.exe --validate
.\Digi67.Engine.exe
```

פתח `http://127.0.0.1:8167/`. ברירת המחדל Demo, ללא גישה לרשת הנמל. עצירה ב־Ctrl+C. הנתונים נוצרים תחת `data/demo` לצד קובץ ההגדרות.

ליצירת פלט הכולל runtime: הרץ `scripts/Publish-Windows.ps1` מתיקיית הפרויקט. אין להחליף רק DLL בתוך פרסום ישן; פרסם לתיקייה חדשה. עיין ב־`docs/DEPLOYMENT.md`, כולל מצב התמיכה ב־.NET 8 והבדיקות שעדיין נדרשות באתר.
