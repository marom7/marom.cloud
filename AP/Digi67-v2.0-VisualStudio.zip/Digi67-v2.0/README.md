# Digi67 v2.0 — מנוע ניטור ‎.NET 8

פרויקט Visual Studio נפרד לפיתוח ולפיילוט: סריקת Ping, קריאת Digi API, איחוד לפי שם כלי, תמונת מצב והיסטוריית JSON, עם הממשק הקיים ב־HTML/CSS/JavaScript. **מערכת הייצור לא שונתה ולא נוצר אליה חיבור בזמן הפיתוח.**

החבילה מבוססת על `digi67.cs`, שתי גרסאות `machines.json`, `index(3).html`, `server(1).js` והממשק מתוך `Digi67-JAM-v2.zip`. רשימת **177 המחשבים ושש הקבוצות נשמרה כפי שסופקה**. העותקים המקוריים וחתימות SHA-256 נמצאים ב־`reference/` ואינם חלק מהקוד שרץ.

## התחלה ב־Visual Studio

1. התקן Visual Studio 2022 **17.11 ומעלה** עם רכיב ASP.NET and web development ו־SDK מסדרת ‎.NET **8.0.4xx**. גרסת SDK שנבדקה: **8.0.428**; Runtime: **8.0.34**.
2. חלץ לתיקייה חדשה, למשל `C:\Digi67-v2-Dev`, ופתח את **Digi67.sln**.
3. קבע את `Digi67.Engine` כ־Startup Project.
4. הפעל את הפרופיל **Digi67 Demo**. כתובת הממשק: **http://127.0.0.1:8167/**.
5. Test → Test Explorer → Run All מפעיל את בדיקות xUnit.

ברירת המחדל היא **Demo**: אין Ping לרשת הנמל, אין בקשות ל־Digi API, אין כתיבה לשיתוף ואין פתיחת Radmin. הנתונים המדומים מסומנים ב־JSON ובממשק. פורט 8167 נבחר בנפרד מהפורט המקורי 8067.

> יעד הבנייה הוא ‎.NET 8 לפי הבקשה. נכון ל־11.11.2026, גרסה זו כבר אחרי תאריך סיום התמיכה הרשמי, 10.11.2026. לפני פריסה תפעולית יש לקבוע מסלול מעבר ל־.NET נתמך. החבילה עצמה לא שינתה את יעד המסגרת. ראו [מדיניות Microsoft](https://dotnet.microsoft.com/en-us/platform/support/policy/dotnet-core).

## הפעלה משורת פקודה

מתוך תיקיית הפרויקט:

```powershell
dotnet restore Digi67.sln --locked-mode
dotnet build Digi67.sln -c Release -m:1
dotnet test Digi67.sln -c Release --no-build -m:1
dotnet run --project src/Digi67.Engine -c Release --no-launch-profile
```

בדיקת הגדרות ללא בקשות רשת וללא יצירת דוחות:

```powershell
dotnet run --project src/Digi67.Engine -c Release --no-launch-profile -- --config config/digi67-config.json --validate
```

מחזור הדגמה יחיד ושמירה מקומית, בלי HTTP ובלי העברה לשיתוף:

```powershell
dotnet run --project src/Digi67.Engine -c Release --no-launch-profile -- --config config/digi67-config.json --once
```

לחלופין: `scripts/Start-Demo.ps1`, `scripts/Build-Test.ps1`. אין צורך ב־Node.js להפעלת המנוע או הממשק.

## מבנה הפרויקט

| מיקום | אחריות |
|---|---|
| `src/Digi67.Core/` | מודלים, הגדרות, PingScanner, DigiClient, DigiCollector, HistoryRecorder וכתיבה אטומית |
| `src/Digi67.Engine/` | תהליך ASP.NET Core, מחזורי איסוף, HTTP לקריאה בלבד והעברה אופציונלית לשיתוף |
| `client/` | הממשק הקודם, מותאם לנתוני Demo/Live, Digi, סטטוס לא ידוע והיסטוריה |
| `config/` | הגדרות Demo, דוגמת Live ורשימת המכונות המקורית |
| `tests/Digi67.Tests/` | בדיקות xUnit עם רשת מדומה, קבצים זמניים ובדיקות כשלים |
| `tests/smoke.py` | בדיקות תהליך ו־HTTP; Python 3.10+ נדרש רק לבדיקה זו |
| `scripts/` | בנייה, בדיקה, פרסום Windows ומשימת פיילוט אופציונלית |
| `docs/` | ארכיטקטורה, חוזה JSON, חיבור API, פריסה ותוצאות בדיקה |
| `reference/` | המקורות לעיון בלבד, מחוץ לבנייה ולפרסום |

אין מסד נתונים, React, ORM, message broker או חבילות NuGet בזמן ריצה. המנוע משתמש ב־.NET וב־ASP.NET Core המובנים; שלוש חבילות NuGet ישירות משמשות את פרויקט הבדיקות בלבד, עם קובץ נעילת גרסאות.

בתיקיית `release/windows-x64/` כלול גם פלט Windows מוכן מסוג framework-dependent. הוא נבנה בהצלחה אך לא הורץ על Windows בסביבה זו; להפעלתו נדרש ASP.NET Core Runtime 8 x64. אפשר ליצור הפצה self-contained באמצעות הסקריפט המצורף.

## מה כבר ממומש

- עד 20 סריקות Ping במקביל, timeout של 3 שניות, המתנה של 60 שניות **מסיום מחזור**. ההגדרות ניתנות לשינוי, ואין מחזורים חופפים.
- טעינת רשימת מכונות בכל מחזור, אימות שמות וכפילויות ושמירת הרשימה התקינה האחרונה בעת עריכה פגומה.
- מתאם Digi HTTP עם אימות TLS, token ממשתנה סביבה, מיפוי שדות, pagination מוגבל וקריאות detail אופציונליות.
- איחוד שמות ללא תלות באותיות גדולות/קטנות; הסרת סיומת הדומיין המוגדרת ו־aliases מפורשים. שמות כפולים מסומנים כעמומים ואינם מתמזגים שרירותית.
- נתוני Ping ונתוני Digi נשמרים בנפרד. נתב מדווח אינו הופך מחשב שלא ענה ל־Ping ל״מחובר״.
- `lastSeen` נשמר גם אחרי ניתוק והפעלה מחדש. כשל DNS/הרשאות/תמיכת ICMP מסומן `unknown`, ולא כמחשב מנותק בוודאות.
- `results.json` נכתב לקובץ זמני באותה תיקייה ומוחלף ללא מחיקת היעד מראש. נעילת תהליך מונעת שני כותבים באותה תיקיית נתונים.
- היסטוריה יומית מסוג JSON Lines: סיכום כל מחזור ומעברי מצב; baseline מלא בתחילת תהליך/יום. שמירה לפי ימים ונפח, תיקון שורה אחרונה שנקטעה.
- worker נפרד להעברה לשיתוף, בתור של תמונת מצב ממתינה אחת. השיתוף כבוי כברירת מחדל; שם היעד הוא `digi67-v2-results.json`.

## גבולות הגרסה

**Digi API לא נבדק מול השרת הפנימי בנמל.** הכתובת הוזכרה בשיחה, אך הקבצים המקוריים אינם מכילים חוזה API מאומת. `/v1/router`, אופן האימות ומיפוי השדות הם הגדרות מועמדות מהתכנון הקודם. הבדיקות משתמשות בתשובות סינתטיות; יש להתאים אותן לתגובה אמיתית לפי [מדריך החיבור](docs/DIGI-API.md).

זוהי חבילת **שלב המנוע**. מעטפת `OPERATOR67.exe`/WebView2, התקנת handler ל־Radmin, שרת IT חדש ומסלול רשת OT↔IT אינם כלולים. ממשק Node הקיים נשאר ללא שינוי. HTTP מקומי בלבד; אין מנגנון משתמשים/הרשאות ארגוני במנוע.

ראה [פריסה ונסיגה](docs/DEPLOYMENT.md), [חוזה נתונים](docs/DATA-CONTRACT.md), [תכנון](docs/ARCHITECTURE.md) ו־[בדיקות שבוצעו](docs/VALIDATION.md).
