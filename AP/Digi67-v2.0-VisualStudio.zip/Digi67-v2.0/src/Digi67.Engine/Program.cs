using System.Globalization;
using System.Text.Json;
using Digi67.Core;
using Digi67.Engine;

var once = false;
var validate = false;
var configPath = Path.Combine(AppContext.BaseDirectory, "digi67-config.json");
for (var i = 0; i < args.Length; i++)
{
    switch (args[i])
    {
        case "--once": once = true; break;
        case "--validate": validate = true; break;
        case "--config" when i + 1 < args.Length: configPath = Path.GetFullPath(args[++i]); break;
        default: Console.Error.WriteLine("Usage: Digi67.Engine [--config FILE] [--validate | --once]"); return 2;
    }
}
try
{
    var options = EngineOptions.Load(configPath);
    var catalog = new MachineCatalog(options.MachinesFile, options);
    var inventory = catalog.Load();
    if (validate)
    {
        Console.WriteLine($"Valid: {MachineCatalog.Flatten(inventory.Catalog).Length} machines; mode={options.Mode}; port={options.LocalPort}. No network requests made.");
        return 0;
    }

    Directory.CreateDirectory(options.DataDirectory);
    // Lifetime lock prevents simultaneous writers, including two --once commands.
    using var instanceLock = new FileStream(Path.Combine(options.DataDirectory, "engine.lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
    var builder = WebApplication.CreateBuilder(new WebApplicationOptions
    {
        Args = [], ContentRootPath = AppContext.BaseDirectory, WebRootPath = Path.Combine(AppContext.BaseDirectory, "wwwroot")
    });
    builder.WebHost.ConfigureKestrel(k => k.Listen(System.Net.IPAddress.Parse(options.BindAddress), options.LocalPort));
    builder.Logging.ClearProviders();
    builder.Logging.AddSimpleConsole(o => { o.SingleLine = true; o.TimestampFormat = "yyyy-MM-dd HH:mm:ss "; });
    builder.Logging.SetMinimumLevel(LogLevel.Warning);
    builder.Logging.AddFilter("Digi67", LogLevel.Information);
    builder.Services.Configure<HostOptions>(o => o.ShutdownTimeout = TimeSpan.FromSeconds(10));
    builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase);
    builder.Services.AddSingleton(options);
    builder.Services.AddSingleton(catalog);
    builder.Services.AddSingleton<RuntimeState>();
    builder.Services.AddSingleton(new PingScanner(options.IsDemo ? new DemoPingProbe() : new SystemPingProbe(), options.BatchSize, options.PingTimeoutMs));
    builder.Services.AddSingleton(new DigiCollector(options));
    builder.Services.AddSingleton(new HistoryRecorder(Path.Combine(options.DataDirectory, "history"), options.History));
    builder.Services.AddSingleton<IDigiSource>(sp => options.IsDemo
        ? new DemoDigiSource(() => MachineCatalog.Flatten(Volatile.Read(ref sp.GetRequiredService<RuntimeState>().Catalog) ?? inventory.Catalog))
        : new DigiClient(sp.GetRequiredService<HttpClient>(), options.DigiApi, Environment.GetEnvironmentVariable));
    builder.Services.AddSingleton(_ => new HttpClient(new SocketsHttpHandler
    {
        AllowAutoRedirect = false, PooledConnectionLifetime = TimeSpan.FromMinutes(5)
    }) { Timeout = Timeout.InfiniteTimeSpan });
    builder.Services.AddSingleton<SharedPublisher>();
    builder.Services.AddSingleton<CollectionService>();
    builder.Services.AddHostedService(sp => sp.GetRequiredService<SharedPublisher>());
    if (!once) builder.Services.AddHostedService(sp => sp.GetRequiredService<CollectionService>());
    await using var app = builder.Build();
    var state = app.Services.GetRequiredService<RuntimeState>();
    var service = app.Services.GetRequiredService<CollectionService>();
    await service.InitializeAsync(CancellationToken.None);

    if (once)
    {
        using var shutdown = new CancellationTokenSource();
        Console.CancelKeyPress += (_, e) => { e.Cancel = true; shutdown.Cancel(); };
        var report = await service.RunOnceAsync(shutdown.Token);
        Console.WriteLine(JsonSerializer.Serialize(new { report.Mode, report.Timestamp, report.Summary }, JsonDefaults.Options));
        // --once deliberately does not start HTTP or the shared-folder worker.
        return state.HistoryError is not null || report.Quality.DigiState == "error" || report.Quality.CatalogState != "current" ? 3 : 0;
    }

    app.Use(async (context, next) =>
    {
        context.Response.Headers.CacheControl = "no-store";
        context.Response.Headers.XContentTypeOptions = "nosniff";
        context.Response.Headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'";
        await next();
    });
    app.UseDefaultFiles();
    app.UseStaticFiles();
    app.MapGet("/api/status", () => SnapshotResult(state));
    app.MapGet("/results.json", () => SnapshotResult(state));
    app.MapGet("/machines.json", () => Results.Json(Volatile.Read(ref state.Catalog), JsonDefaults.Options));
    app.MapGet("/api/machines", () => Results.Json(Volatile.Read(ref state.Catalog), JsonDefaults.Options));
    app.MapGet("/api/ui-config", () => Results.Json(new { options.Mode, options.StaleAfterSeconds, options.EnableRadminLinks }));
    app.MapGet("/api/health", () =>
    {
        var health = Health.Describe(state, options, DateTimeOffset.UtcNow);
        return Results.Json(health.Body, statusCode: health.StatusCode);
    });
    app.MapGet("/api/history", async (HttpContext context, HistoryRecorder history) =>
    {
        var query = context.Request.Query;
        var dateText = query["date"].FirstOrDefault() ?? DateTimeOffset.UtcNow.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        if (!DateOnly.TryParseExact(dateText, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var date) ||
            !int.TryParse(query["limit"].FirstOrDefault() ?? "100", out var limit) || limit is < 1 or > 500 ||
            !int.TryParse(query["offset"].FirstOrDefault() ?? "0", out var offset) || offset is < 0 or > 1000000)
            return Results.BadRequest(new { error = "date=yyyy-MM-dd UTC; limit=1..500; offset=0..1000000" });
        try { return Results.Json(await history.ReadAsync(date, query["machine"].FirstOrDefault(), offset, limit, context.RequestAborted), JsonDefaults.Options); }
        catch (IOException) { return Results.Json(new { error = "history_unavailable" }, statusCode: 503); }
    });
    app.Logger.LogInformation("Digi67 v2.0 {Mode}: http://{Bind}:{Port}/; config {File}", options.Mode, options.BindAddress, options.LocalPort, Path.GetFileName(configPath));
    await app.RunAsync();
    return 0;
}
catch (OperationCanceledException) { return 130; }
catch (Exception ex) when (ex is IOException or InvalidDataException or JsonException or UnauthorizedAccessException or ArgumentException)
{
    Console.Error.WriteLine($"Startup/validation failed ({ex.GetType().Name}). Check config, inventory, write permissions, port, and single-instance lock. No secrets are logged.");
    return 2;
}

static IResult SnapshotResult(RuntimeState state) => Volatile.Read(ref state.Snapshot) is { } snapshot
    ? Results.Json(snapshot, JsonDefaults.Options)
    : Results.Json(new { error = "awaiting_first_cycle" }, statusCode: 503);

public partial class Program;
