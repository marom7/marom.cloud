using System.Threading.Channels;
using Digi67.Core;

namespace Digi67.Engine;

// One writer, one pending snapshot. An unavailable SMB path cannot hold up Ping/API collection.
public sealed class SharedPublisher(EngineOptions options, RuntimeState state, ILogger<SharedPublisher> logger) : BackgroundService
{
    private readonly Channel<Snapshot> _queue = Channel.CreateBounded<Snapshot>(new BoundedChannelOptions(1)
    {
        SingleReader = true, SingleWriter = true, FullMode = BoundedChannelFullMode.DropOldest
    });
    public void Enqueue(Snapshot snapshot)
    {
        if (!options.IsDemo && !string.IsNullOrWhiteSpace(options.SharedFolder)) _queue.Writer.TryWrite(snapshot);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (options.IsDemo || string.IsNullOrWhiteSpace(options.SharedFolder)) return;
        Volatile.Write(ref state.Share, new("waiting", null, null, null));
        await foreach (var snapshot in _queue.Reader.ReadAllAsync(stoppingToken))
        {
            var previous = Volatile.Read(ref state.Share);
            var attempted = DateTimeOffset.UtcNow;
            Volatile.Write(ref state.Share, previous with { State = "writing", LastAttempt = attempted, ErrorCode = null });
            try
            {
                // Run synchronous SMB open/rename calls away from collection and HTTP request threads.
                await Task.Run(async () =>
                {
                    if (!Directory.Exists(options.SharedFolder)) throw new DirectoryNotFoundException();
                    await AtomicJsonFile.WriteAsync(Path.Combine(options.SharedFolder, options.SharedFileName), snapshot, stoppingToken);
                }, stoppingToken);
                Volatile.Write(ref state.Share, new("current", DateTimeOffset.UtcNow, attempted, null, snapshot.Timestamp));
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { return; }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                Volatile.Write(ref state.Share, new("error", previous.LastSuccess, attempted, "shared_write_failed", previous.SnapshotTimestamp));
                logger.LogWarning("Shared publication failed ({ErrorType}); next cycle will retry.", ex.GetType().Name);
            }
        }
    }
}
