using System.Diagnostics;
using System.Text.Json;
using Digi67.Core;

namespace Digi67.Engine;

public sealed class CollectionService(EngineOptions options, MachineCatalog catalog, PingScanner scanner,
    IDigiSource digi, DigiCollector collector, HistoryRecorder history, RuntimeState state,
    SharedPublisher publisher, ILogger<CollectionService> logger) : BackgroundService
{
    private readonly SemaphoreSlim _cycle = new(1, 1);
    private bool _initialized;
    private Snapshot? _historyPrevious;

    public async Task InitializeAsync(CancellationToken cancellationToken)
    {
        if (_initialized) return;
        Directory.CreateDirectory(options.DataDirectory);
        state.Catalog = catalog.Load().Catalog;
        try { state.Snapshot = await AtomicJsonFile.ReadSnapshotAsync(Path.Combine(options.DataDirectory, "results.json"), options.Mode, cancellationToken); }
        catch (Exception ex) when (ex is IOException or JsonException or InvalidDataException or UnauthorizedAccessException)
        {
            var existing = Path.Combine(options.DataDirectory, "results.json");
            if (File.Exists(existing)) File.Copy(existing, existing + ".corrupt-" + DateTimeOffset.UtcNow.ToString("yyyyMMddHHmmssfff"), overwrite: false);
            state.RecoveryWarning = "previous_snapshot_invalid_lastSeen_reset";
            logger.LogWarning("Previous snapshot is invalid; a diagnostic copy is retained. LastSeen restarts from unknown.");
        }
        _initialized = true;
    }

    public async Task<Snapshot> RunOnceAsync(CancellationToken cancellationToken)
    {
        await _cycle.WaitAsync(cancellationToken);
        try
        {
            await InitializeAsync(cancellationToken);
            var sw = Stopwatch.StartNew();
            var inventory = catalog.Load();
            Volatile.Write(ref state.Catalog, inventory.Catalog);
            var pingTask = scanner.ScanAsync(MachineCatalog.Flatten(inventory.Catalog), cancellationToken);
            var digiTask = digi.FetchAsync(cancellationToken);
            await Task.WhenAll(pingTask, digiTask);
            var previous = Volatile.Read(ref state.Snapshot);
            var snapshot = collector.Merge(inventory, await pingTask, await digiTask, previous, DateTimeOffset.UtcNow, sw.ElapsedMilliseconds);
            try
            {
                // Begin every process/day with a full state baseline. Failed history writes do not
                // advance this checkpoint, so recovered history compares against its last durable state.
                var baseline = _historyPrevious?.Timestamp.UtcDateTime.Date == snapshot.Timestamp.UtcDateTime.Date ? _historyPrevious : null;
                await history.AppendAsync(DigiCollector.Changes(snapshot, baseline), cancellationToken);
                _historyPrevious = snapshot;
                state.HistoryError = null;
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                state.HistoryError = "history_write_failed";
                logger.LogError("History write failed ({ErrorType}); current snapshot will still be published.", ex.GetType().Name);
            }
            await AtomicJsonFile.WriteAsync(Path.Combine(options.DataDirectory, "results.json"), snapshot, cancellationToken);
            Volatile.Write(ref state.Snapshot, snapshot);
            state.CycleError = null;
            publisher.Enqueue(snapshot);
            logger.LogInformation("Cycle {Id}: {Online}/{Total} replies, {Unknown} unknown, Digi {DigiState}, {Ms} ms, mode {Mode}",
                snapshot.CycleId, snapshot.Summary.Online, snapshot.Summary.Total, snapshot.Summary.Unknown,
                snapshot.Quality.DigiState, snapshot.CycleDurationMs, snapshot.Mode);
            return snapshot;
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch
        {
            state.CycleError = "cycle_failed";
            throw;
        }
        finally { _cycle.Release(); }
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try { await RunOnceAsync(stoppingToken); }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { return; }
            catch (Exception ex) { logger.LogError("Cycle failed ({ErrorType}); previous complete snapshot is retained.", ex.GetType().Name); }
            await Task.Delay(TimeSpan.FromSeconds(options.IntervalSeconds), stoppingToken);
        }
    }
}
