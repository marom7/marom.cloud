using Digi67.Core;

namespace Digi67.Engine;

public sealed class RuntimeState
{
    public Snapshot? Snapshot;
    public Catalog? Catalog;
    public string? CycleError;
    public string? HistoryError;
    public string? RecoveryWarning;
    public ShareStatus Share = new("disabled", null, null, null);
}

public sealed record ShareStatus(string State, DateTimeOffset? LastSuccess, DateTimeOffset? LastAttempt, string? ErrorCode,
    DateTimeOffset? SnapshotTimestamp = null);

public static class Health
{
    public static (int StatusCode, object Body) Describe(RuntimeState state, EngineOptions options, DateTimeOffset now)
    {
        var snapshot = Volatile.Read(ref state.Snapshot);
        var share = Volatile.Read(ref state.Share);
        var age = snapshot is null ? (double?)null : (now - snapshot.Timestamp).TotalSeconds;
        var fresh = age is >= -60 && age <= options.StaleAfterSeconds;
        var shareLag = !string.IsNullOrWhiteSpace(options.SharedFolder) &&
                       (share.SnapshotTimestamp is null || (now - share.SnapshotTimestamp.Value).TotalSeconds > options.StaleAfterSeconds);
        var degraded = !fresh || state.CycleError is not null || state.HistoryError is not null ||
                       snapshot?.Quality.CatalogState != "current" || snapshot?.Quality.DigiState == "error" ||
                       snapshot?.Quality.AmbiguousDigiNames.Length > 0 || snapshot?.Summary.Unknown > 0 || share.State == "error" || shareLag;
        return (degraded ? 503 : 200, new
        {
            status = degraded ? "degraded" : "healthy", mode = options.Mode,
            fresh, ageSeconds = age, lastSnapshot = snapshot?.Timestamp, unknownMachines = snapshot?.Summary.Unknown, cycleError = state.CycleError,
            historyError = state.HistoryError, recoveryWarning = state.RecoveryWarning, quality = snapshot?.Quality,
            share = new { share.State, share.LastSuccess, share.LastAttempt, share.ErrorCode, share.SnapshotTimestamp },
            version = "2.0.0"
        });
    }
}
