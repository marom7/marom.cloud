using System.Globalization;
using System.Text.Json;

namespace Digi67.Core;

// Read-only vendor adapter. HttpClient is reused; redirects and TLS bypass are never enabled.
public sealed class DigiClient(HttpClient http, DigiApiOptions options, Func<string, string?> readEnvironment,
    TimeProvider? clock = null) : IDigiSource
{
    private readonly TimeProvider _clock = clock ?? TimeProvider.System;

    public async Task<DigiFetch> FetchAsync(CancellationToken cancellationToken)
    {
        if (!options.Enabled) return DigiFetch.Disabled;
        var token = readEnvironment(options.TokenEnvironmentVariable);
        if (string.IsNullOrWhiteSpace(token) || token.Contains('\r') || token.Contains('\n')) return DigiFetch.Failed("missing_or_invalid_token");
        try
        {
            var fetched = _clock.GetUtcNow();
            var rows = new List<DigiReading>();
            var visited = new HashSet<Uri>();
            var next = SafeUri(options.ListPath);
            while (true)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (visited.Count >= options.MaxPages || !visited.Add(next)) throw new InvalidDataException("pagination_limit_or_loop");
                using var doc = await GetJsonAsync(next, token, cancellationToken);
                var items = Select(doc.RootElement, options.ItemsPath);
                if (items.ValueKind != JsonValueKind.Array) throw new JsonException("Items path is not an array.");
                foreach (var item in items.EnumerateArray()) rows.Add(ParseReading(item, fetched));
                var nextNode = string.IsNullOrWhiteSpace(options.NextPath) ? default : Select(doc.RootElement, options.NextPath);
                if (nextNode.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined) break;
                if (nextNode.ValueKind != JsonValueKind.String) throw new JsonException("Next URL must be a string or null.");
                var link = nextNode.GetString();
                if (string.IsNullOrWhiteSpace(link)) break;
                next = SafeUri(link, next);
            }

            if (!string.IsNullOrEmpty(options.DetailPath))
            {
                var details = new DigiReading[rows.Count];
                await Parallel.ForEachAsync(Enumerable.Range(0, rows.Count), new ParallelOptions
                {
                    MaxDegreeOfParallelism = options.DetailConcurrency, CancellationToken = cancellationToken
                }, async (i, ct) =>
                {
                    var row = rows[i];
                    if (string.IsNullOrWhiteSpace(row.Id)) throw new JsonException("Detail requires id.");
                    var uri = SafeUri(options.DetailPath.Replace("{id}", Uri.EscapeDataString(row.Id), StringComparison.Ordinal));
                    using var doc = await GetJsonAsync(uri, token, ct);
                    var detail = ParseReading(Select(doc.RootElement, options.DetailRootPath), fetched);
                    if (!string.Equals(detail.DisplayName.Trim(), row.DisplayName.Trim(), StringComparison.OrdinalIgnoreCase) ||
                        (detail.Id is not null && detail.Id != row.Id)) throw new JsonException("Detail identity differs from list.");
                    details[i] = detail;
                });
                rows = [.. details];
            }
            return new("success", rows.ToArray(), fetched, null);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (OperationCanceledException) { return DigiFetch.Failed("timeout"); }
        catch (HttpRequestException ex) { return DigiFetch.Failed(ex.StatusCode is null ? "transport_or_tls_error" : $"http_{(int)ex.StatusCode}"); }
        catch (JsonException) { return DigiFetch.Failed("invalid_json_or_mapping"); }
        catch (InvalidDataException) { return DigiFetch.Failed("response_limit_or_invalid_pagination"); }
        catch (Exception ex) when (ex is FormatException or ArgumentException or IOException or OverflowException)
        { return DigiFetch.Failed("invalid_response_or_configuration"); }
    }

    private Uri SafeUri(string path, Uri? relativeTo = null)
    {
        var origin = new Uri(options.BaseUrl.TrimEnd('/') + "/");
        var uri = new Uri(relativeTo ?? origin, path);
        if (uri.Scheme != "https" || uri.Host != origin.Host || uri.Port != origin.Port || uri.UserInfo.Length != 0 || uri.Fragment.Length != 0)
            throw new InvalidDataException("Cross-origin pagination/request is prohibited.");
        return uri;
    }

    private async Task<JsonDocument> GetJsonAsync(Uri uri, string token, CancellationToken cancellationToken)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(TimeSpan.FromSeconds(options.TimeoutSeconds));
        using var request = new HttpRequestMessage(HttpMethod.Get, uri);
        var auth = string.IsNullOrEmpty(options.AuthScheme) ? token : options.AuthScheme + " " + token;
        if (!request.Headers.TryAddWithoutValidation(options.AuthHeader, auth)) throw new InvalidDataException("Invalid auth header.");
        request.Headers.Accept.ParseAdd("application/json");
        using var response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, timeout.Token);
        response.EnsureSuccessStatusCode();
        if (response.Content.Headers.ContentLength > options.MaxResponseBytes) throw new InvalidDataException("Response too large.");
        await using var stream = await response.Content.ReadAsStreamAsync(timeout.Token);
        using var buffer = new MemoryStream();
        var bytes = new byte[8192];
        int count;
        while ((count = await stream.ReadAsync(bytes, timeout.Token)) > 0)
        {
            if (buffer.Length + count > options.MaxResponseBytes) throw new InvalidDataException("Response too large.");
            buffer.Write(bytes, 0, count);
        }
        return JsonDocument.Parse(buffer.ToArray());
    }

    private DigiReading ParseReading(JsonElement row, DateTimeOffset fetched)
    {
        if (row.ValueKind != JsonValueKind.Object) throw new JsonException("Router item must be an object.");
        JsonElement Field(string field) => options.Fields.TryGetValue(field, out var path) && !string.IsNullOrWhiteSpace(path) ? Select(row, path) : default;
        var name = ReadText(Field("name"));
        if (string.IsNullOrWhiteSpace(name) || name.Length > 253) throw new JsonException("Router name is required.");
        var lastSeen = ReadNumber(Field("lastSeen"));
        return new DigiReading
        {
            DisplayName = name.Trim(), Id = ReadText(Field("id")), FetchedAt = fetched,
            RouterLastSeen = lastSeen is null ? null : DateTimeOffset.FromUnixTimeSeconds(checked((long)lastSeen.Value)),
            TemperatureCelsius = ReadNumber(Field("temperature")), UptimeSeconds = ReadNumber(Field("uptime")),
            WanPingMs = ReadNumber(Field("wanPing")), Reboots24h = ReadInteger(Field("reboots24h")), Reboots30d = ReadInteger(Field("reboots30d")),
            UsageTodayBytes = ReadNumber(Field("usageToday")), FirmwareVersion = ReadText(Field("firmware")), ActiveWan = ReadText(Field("activeWan"))
        };
    }

    public static JsonElement Select(JsonElement root, string path)
    {
        if (string.IsNullOrEmpty(path)) return root;
        var current = root;
        foreach (var part in path.Split('.'))
        {
            if (current.ValueKind != JsonValueKind.Object || !current.TryGetProperty(part, out current)) return default;
        }
        return current;
    }

    private static string? ReadText(JsonElement value) => value.ValueKind switch
    {
        JsonValueKind.Undefined or JsonValueKind.Null => null,
        JsonValueKind.String => value.GetString(),
        JsonValueKind.Number => value.GetRawText(),
        _ => throw new JsonException("Expected string/number.")
    };
    private static double? ReadNumber(JsonElement value)
    {
        if (value.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined) return null;
        if (double.TryParse(ReadText(value), NumberStyles.Float, CultureInfo.InvariantCulture, out var n) && double.IsFinite(n)) return n;
        throw new JsonException("Invalid numeric telemetry.");
    }
    private static long? ReadInteger(JsonElement value)
    {
        var n = ReadNumber(value);
        if (n is null) return null;
        if (n < 0 || n != Math.Truncate(n.Value)) throw new JsonException("Invalid counter.");
        return checked((long)n.Value);
    }
}

public sealed class DemoDigiSource(Func<Machine[]> machines, TimeProvider? clock = null) : IDigiSource
{
    public Task<DigiFetch> FetchAsync(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var now = (clock ?? TimeProvider.System).GetUtcNow();
        var rows = machines().Where((_, i) => i % 5 == 0).Select((m, i) => new DigiReading
        {
            DisplayName = m.Address, Id = "DEMO-" + i, FetchedAt = now, RouterLastSeen = now,
            TemperatureCelsius = 35 + i % 8, FirmwareVersion = "DEMO", ActiveWan = i % 2 == 0 ? "WiFi (DEMO)" : "Cellular (DEMO)"
        }).ToArray();
        return Task.FromResult(new DigiFetch("success", rows, now, null));
    }
}
