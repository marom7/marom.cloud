using System.Net;
using System.Text.Json;

namespace Digi67.Core;

public sealed class EngineOptions
{
    public string Mode { get; set; } = "Demo";
    public string AgentName { get; set; } = Environment.MachineName;
    public int IntervalSeconds { get; set; } = 60;
    public int PingTimeoutMs { get; set; } = 3000;
    public int BatchSize { get; set; } = 20;
    public int LocalPort { get; set; } = 8167;
    public string BindAddress { get; set; } = "127.0.0.1";
    public string MachinesFile { get; set; } = "machines.json";
    public string DataDirectory { get; set; } = "data";
    public int StaleAfterSeconds { get; set; } = 180;
    public string SharedFolder { get; set; } = "";
    public string SharedFileName { get; set; } = "digi67-v2-results.json";
    public bool EnableRadminLinks { get; set; }
    public string[] StripDomainSuffixes { get; set; } = [".ashdodport.co.il"];
    public Dictionary<string, string> DigiAliases { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public DigiApiOptions DigiApi { get; set; } = new();
    public HistoryOptions History { get; set; } = new();
    public bool IsDemo => Mode == "Demo";

    public static EngineOptions Load(string configPath)
    {
        var result = JsonSerializer.Deserialize<EngineOptions>(File.ReadAllText(configPath), JsonDefaults.Options)
                     ?? throw new InvalidDataException("Configuration is empty.");
        result.Validate();
        var root = Path.GetDirectoryName(Path.GetFullPath(configPath))!;
        result.MachinesFile = Path.GetFullPath(result.MachinesFile, root);
        result.DataDirectory = Path.Combine(Path.GetFullPath(result.DataDirectory, root), result.Mode.ToLowerInvariant());
        if (!string.IsNullOrWhiteSpace(result.SharedFolder)) result.SharedFolder = Path.GetFullPath(result.SharedFolder, root);
        return result;
    }

    public void Validate()
    {
        if (Mode is not ("Demo" or "Live")) throw new InvalidDataException("Mode must be Demo or Live.");
        Range(IntervalSeconds, 1, 86400, nameof(IntervalSeconds));
        Range(PingTimeoutMs, 100, 30000, nameof(PingTimeoutMs));
        Range(BatchSize, 1, 100, nameof(BatchSize));
        Range(LocalPort, 1024, 65535, nameof(LocalPort));
        Range(StaleAfterSeconds, 1, 86400, nameof(StaleAfterSeconds));
        if (!IPAddress.TryParse(BindAddress, out var bind) || !IPAddress.IsLoopback(bind))
            throw new InvalidDataException("This pilot exposes HTTP on loopback only. Use an approved authenticated proxy for LAN access.");
        if (string.IsNullOrWhiteSpace(MachinesFile) || string.IsNullOrWhiteSpace(DataDirectory) || string.IsNullOrWhiteSpace(AgentName))
            throw new InvalidDataException("MachinesFile, DataDirectory and AgentName are required.");
        if (SharedFolder is null || SharedFileName is null || !System.Text.RegularExpressions.Regex.IsMatch(SharedFileName, @"^[a-zA-Z0-9_-]+\.json$"))
            throw new InvalidDataException("SharedFileName must be a simple JSON filename.");
        if (IsDemo && (DigiApi?.Enabled == true || !string.IsNullOrWhiteSpace(SharedFolder) || EnableRadminLinks))
            throw new InvalidDataException("Demo prohibits live Digi API, shared-folder writes and Radmin links.");
        if (StripDomainSuffixes is null || StripDomainSuffixes.Any(s => string.IsNullOrWhiteSpace(s) || !s.StartsWith('.')) || DigiAliases is null)
            throw new InvalidDataException("Invalid identity settings.");
        DigiAliases = new Dictionary<string, string>(DigiAliases, StringComparer.OrdinalIgnoreCase);
        if (DigiAliases.Any(p => string.IsNullOrWhiteSpace(p.Key) || string.IsNullOrWhiteSpace(p.Value)))
            throw new InvalidDataException("Aliases cannot be blank.");
        (DigiApi ?? throw new InvalidDataException("DigiApi is required.")).Validate();
        (History ?? throw new InvalidDataException("History is required.")).Validate();
    }

    internal static void Range(int n, int min, int max, string name)
    {
        if (n < min || n > max) throw new InvalidDataException($"{name} must be {min}..{max}.");
    }
}

public sealed class HistoryOptions
{
    public int RetentionDays { get; set; } = 30;
    public int SegmentMegabytes { get; set; } = 16;
    public int MaxTotalMegabytes { get; set; } = 256;
    public void Validate()
    {
        EngineOptions.Range(RetentionDays, 1, 3650, nameof(RetentionDays));
        EngineOptions.Range(SegmentMegabytes, 1, 64, nameof(SegmentMegabytes));
        EngineOptions.Range(MaxTotalMegabytes, SegmentMegabytes * 2, 4096, nameof(MaxTotalMegabytes));
    }
}

// Candidate mapping from the earlier design, NOT a verified on-site API contract.
public sealed class DigiApiOptions
{
    public bool Enabled { get; set; }
    public string BaseUrl { get; set; } = "https://10.50.71.46";
    public string ListPath { get; set; } = "/v1/router";
    public string ItemsPath { get; set; } = "results"; // empty = root array
    public string NextPath { get; set; } = "next";     // empty = no pagination
    public string DetailPath { get; set; } = "";       // optional /v1/router/{id}
    public string DetailRootPath { get; set; } = "";
    public string TokenEnvironmentVariable { get; set; } = "DIGI67_API_TOKEN";
    public string AuthHeader { get; set; } = "Authorization";
    public string AuthScheme { get; set; } = "";       // empty = raw token
    public int TimeoutSeconds { get; set; } = 10;
    public int MaxPages { get; set; } = 10;
    public int DetailConcurrency { get; set; } = 4;
    public int MaxResponseBytes { get; set; } = 2097152;
    public Dictionary<string, string> Fields { get; set; } = new()
    {
        ["name"] = "display_name", ["id"] = "id", ["lastSeen"] = "last_seen_unixtime",
        ["temperature"] = "temperature.celsius", ["uptime"] = "uptime", ["wanPing"] = "wan.ping",
        ["reboots24h"] = "reboots_24h", ["reboots30d"] = "reboots_30d",
        ["usageToday"] = "data_usage.usage_today", ["firmware"] = "router_type.firmware_version",
        ["activeWan"] = "" // configure from a real response; never infer WiFi/Cellular from ICMP
    };

    public void Validate()
    {
        EngineOptions.Range(TimeoutSeconds, 1, 120, nameof(TimeoutSeconds));
        EngineOptions.Range(MaxPages, 1, 100, nameof(MaxPages));
        EngineOptions.Range(DetailConcurrency, 1, 20, nameof(DetailConcurrency));
        EngineOptions.Range(MaxResponseBytes, 1024, 16777216, nameof(MaxResponseBytes));
        if (Fields is null || !Fields.TryGetValue("name", out var name) || string.IsNullOrWhiteSpace(name))
            throw new InvalidDataException("Digi name field mapping is required.");
        if (!Enabled) return;
        if (!Uri.TryCreate(BaseUrl, UriKind.Absolute, out var uri) || uri.Scheme != "https" || uri.UserInfo.Length != 0 || uri.Query.Length != 0 || uri.Fragment.Length != 0)
            throw new InvalidDataException("Digi BaseUrl must be HTTPS without embedded credentials/query/fragment.");
        if (string.IsNullOrWhiteSpace(ListPath) || string.IsNullOrWhiteSpace(TokenEnvironmentVariable) || string.IsNullOrWhiteSpace(AuthHeader) || AuthScheme is null)
            throw new InvalidDataException("Digi request settings are incomplete.");
        if (!System.Text.RegularExpressions.Regex.IsMatch(AuthHeader, "^[A-Za-z0-9-]+$") || AuthScheme.Contains('\r') || AuthScheme.Contains('\n'))
            throw new InvalidDataException("Invalid Digi authorization header.");
        if (!string.IsNullOrEmpty(DetailPath) && !DetailPath.Contains("{id}", StringComparison.Ordinal))
            throw new InvalidDataException("DetailPath must contain {id}.");
    }
}
