using System.Net.NetworkInformation;

namespace Digi67.Core;

public sealed class SystemPingProbe(TimeProvider? clock = null) : IPingProbe
{
    private readonly TimeProvider _clock = clock ?? TimeProvider.System;

    public async Task<PingObservation> ProbeAsync(string address, int timeoutMs, CancellationToken cancellationToken)
    {
        try
        {
            using var ping = new Ping();
            var reply = await ping.SendPingAsync(address, TimeSpan.FromMilliseconds(timeoutMs), cancellationToken: cancellationToken);
            return new(address, reply.Status == IPStatus.Success,
                reply.Status == IPStatus.Success ? reply.RoundtripTime : null, reply.Status.ToString(), _clock.GetUtcNow());
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception ex) when (ex is PingException or System.Net.Sockets.SocketException or InvalidOperationException or UnauthorizedAccessException or System.Security.SecurityException or PlatformNotSupportedException)
        {
            // DNS/permission/ICMP errors are unknown, not proof that a computer is offline.
            return new(address, null, null, "ProbeError", _clock.GetUtcNow());
        }
    }
}

public sealed class DemoPingProbe(TimeProvider? clock = null) : IPingProbe
{
    private readonly TimeProvider _clock = clock ?? TimeProvider.System;
    public Task<PingObservation> ProbeAsync(string address, int timeoutMs, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var hash = address.Aggregate(0, (n, c) => (n * 31 + c) & 0xffff);
        var online = hash % 7 != 0;
        return Task.FromResult(new PingObservation(address, online, online ? 5 + hash % 70 : null,
            online ? "Success" : "TimedOut", _clock.GetUtcNow()));
    }
}

public sealed class PingScanner(IPingProbe probe, int concurrency, int timeoutMs)
{
    public async Task<PingObservation[]> ScanAsync(Machine[] machines, CancellationToken cancellationToken)
    {
        EngineOptions.Range(concurrency, 1, 100, nameof(concurrency));
        var results = new PingObservation[machines.Length];
        await Parallel.ForEachAsync(Enumerable.Range(0, machines.Length), new ParallelOptions
        {
            MaxDegreeOfParallelism = concurrency, CancellationToken = cancellationToken
        }, async (index, ct) => results[index] = await probe.ProbeAsync(machines[index].Address, timeoutMs, ct));
        return results;
    }
}
