using System.Text.Json;
using System.Text.Json.Serialization;

namespace Digi67.Core;

public static class JsonDefaults
{
    public static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web)
    {
        UnmappedMemberHandling = JsonUnmappedMemberHandling.Skip
    };
}

public sealed record Category(string Key, string Name, string Icon, string Color, string[] Addresses);
public sealed record Catalog(Category[] Categories);
public sealed record Machine(string Address, string Category, string CategoryHe);
public sealed record CatalogLoad(Catalog Catalog, string State, string? ErrorCode);
public sealed record PingObservation(string Address, bool? Connected, double? PingMs, string Status, DateTimeOffset ObservedAt);

// All telemetry is optional. Router reachability NEVER overwrites the computer's ICMP result.
public sealed record DigiReading
{
    public required string DisplayName { get; init; }
    public string? Id { get; init; }
    public DateTimeOffset FetchedAt { get; init; }
    public DateTimeOffset? RouterLastSeen { get; init; }
    public double? TemperatureCelsius { get; init; }
    public double? UptimeSeconds { get; init; }
    public double? WanPingMs { get; init; }
    public long? Reboots24h { get; init; }
    public long? Reboots30d { get; init; }
    public double? UsageTodayBytes { get; init; }
    public string? FirmwareVersion { get; init; }
    public string? ActiveWan { get; init; }
}

public sealed record DigiFetch(string State, DigiReading[] Readings, DateTimeOffset? FetchedAt, string? ErrorCode)
{
    public static DigiFetch Disabled => new("disabled", [], null, null);
    public static DigiFetch Failed(string code) => new("error", [], null, code);
}

public sealed record MachineResult
{
    public required string Address { get; init; }
    public required string Category { get; init; }
    public required string CategoryHe { get; init; }
    public bool? Connected { get; init; }
    public double? PingMs { get; init; }
    public required string PingStatus { get; init; }
    public DateTimeOffset? LastSeen { get; init; }
    public required string DigiStatus { get; init; }
    public DigiReading? Digi { get; init; }
}

public sealed record Summary(int Total, int Online, int Offline, int Unknown, double? AveragePingMs);
public sealed record CategoryInfo(string Key, string Name, string Icon, string Color);
public sealed record Quality(string CatalogState, string? CatalogError, string DigiState, string? DigiError,
    string[] UnmatchedDigiNames, string[] AmbiguousDigiNames);

public sealed record Snapshot
{
    public string SchemaVersion { get; init; } = "2.0";
    public required string CycleId { get; init; }
    public required string Mode { get; init; }
    public DateTimeOffset Timestamp { get; init; }
    public required string AgentName { get; init; }
    public long CycleDurationMs { get; init; }
    public int StaleAfterSeconds { get; init; }
    public required Summary Summary { get; init; }
    public required CategoryInfo[] Categories { get; init; }
    public required MachineResult[] Machines { get; init; }
    public required Quality Quality { get; init; }
}

public sealed record MachineChange(string Address, string Kind, bool? PreviousConnected, MachineResult? Current);
public sealed record HistoryRecord(string CycleId, DateTimeOffset Timestamp, string Mode, Summary Summary,
    Quality Quality, MachineChange[] Changes);
public sealed record HistoryPage(HistoryRecord[] Records, int? NextOffset, int InvalidLines);

public interface IPingProbe
{
    Task<PingObservation> ProbeAsync(string address, int timeoutMs, CancellationToken cancellationToken);
}
public interface IDigiSource
{
    Task<DigiFetch> FetchAsync(CancellationToken cancellationToken);
}
