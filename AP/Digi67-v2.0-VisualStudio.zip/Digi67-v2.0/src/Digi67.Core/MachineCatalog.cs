using System.Net;
using System.Text.Json;

namespace Digi67.Core;

public sealed class MachineCatalog(string path, EngineOptions options)
{
    private Catalog? _lastGood;
    private string? _lastText;

    // A 3 KB inventory is read each cycle. No watcher, timestamp race or extra dependency.
    public CatalogLoad Load()
    {
        try
        {
            var text = File.ReadAllText(path);
            if (text != _lastText)
            {
                var catalog = JsonSerializer.Deserialize<Catalog>(text, JsonDefaults.Options)
                              ?? throw new InvalidDataException("Empty inventory.");
                Validate(catalog, options);
                _lastGood = catalog;
                _lastText = text;
            }
            return new(_lastGood!, "current", null);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException or InvalidDataException or ArgumentException)
        {
            if (_lastGood is null) throw new InvalidDataException("No valid machines.json is available. Fix the inventory before starting.", ex);
            return new(_lastGood, "lastGood", "inventory_reload_failed");
        }
    }

    public static void Validate(Catalog catalog, EngineOptions options)
    {
        if (catalog.Categories is null || catalog.Categories.Length == 0) throw new InvalidDataException("No categories.");
        var keys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var hosts = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var identities = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var c in catalog.Categories)
        {
            if (c is null || string.IsNullOrWhiteSpace(c.Key) || string.IsNullOrWhiteSpace(c.Name) || !keys.Add(c.Key) || c.Addresses is null)
                throw new InvalidDataException("Invalid or duplicate category.");
            foreach (var address in c.Addresses)
            {
                if (string.IsNullOrWhiteSpace(address) || address.Length > 253 || address != address.Trim() ||
                    Uri.CheckHostName(address) == UriHostNameType.Unknown || !hosts.Add(address) ||
                    !identities.Add(Identity.ForMachine(address, options)))
                    throw new InvalidDataException("Invalid/duplicate host or ambiguous merge identity.");
            }
        }
        if (hosts.Count is < 1 or > 10000) throw new InvalidDataException("Inventory must contain 1..10000 machines.");
    }

    public static Machine[] Flatten(Catalog catalog) => catalog.Categories
        .SelectMany(c => c.Addresses.Select(a => new Machine(a, c.Key, c.Name))).ToArray();
}

public static class Identity
{
    public static string Normalize(string value, EngineOptions options)
    {
        var name = value.Trim().TrimEnd('.');
        if (!IPAddress.TryParse(name, out _))
            foreach (var suffix in options.StripDomainSuffixes.OrderByDescending(s => s.Length))
                if (name.EndsWith(suffix, StringComparison.OrdinalIgnoreCase))
                {
                    name = name[..^suffix.Length];
                    break;
                }
        return name.ToUpperInvariant();
    }

    public static string ForMachine(string address, EngineOptions options) => Normalize(
        options.DigiAliases.TryGetValue(address, out var alias) ? alias : address, options);
}
