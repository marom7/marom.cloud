using System.Text.Json;

namespace Digi67.Core;

public static class AtomicJsonFile
{
    // Same-directory temp + rename/replace; never delete the destination first.
    // Readers see a complete old/new file on filesystems providing atomic rename (verify SMB server semantics).
    public static async Task WriteAsync<T>(string path, T value, CancellationToken cancellationToken = default)
    {
        var temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            await using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                             16384, FileOptions.Asynchronous | FileOptions.WriteThrough))
            {
                await JsonSerializer.SerializeAsync(stream, value, JsonDefaults.Options, cancellationToken);
                await stream.FlushAsync(cancellationToken);
                stream.Flush(flushToDisk: true);
            }
            cancellationToken.ThrowIfCancellationRequested();
            File.Move(temp, path, overwrite: true);
        }
        finally
        {
            try { if (File.Exists(temp)) File.Delete(temp); }
            catch (IOException) { }
        }
    }

    public static async Task<Snapshot?> ReadSnapshotAsync(string path, string mode, CancellationToken cancellationToken = default)
    {
        if (!File.Exists(path)) return null;
        await using var stream = File.OpenRead(path);
        var snapshot = await JsonSerializer.DeserializeAsync<Snapshot>(stream, JsonDefaults.Options, cancellationToken);
        if (snapshot?.Mode != mode || snapshot.Machines is null || snapshot.Machines.Any(m => m is null || string.IsNullOrWhiteSpace(m.Address)) ||
            snapshot.Machines.Select(m => m.Address).Distinct(StringComparer.OrdinalIgnoreCase).Count() != snapshot.Machines.Length)
            throw new InvalidDataException("Stored snapshot is invalid or belongs to another mode.");
        return snapshot;
    }
}
