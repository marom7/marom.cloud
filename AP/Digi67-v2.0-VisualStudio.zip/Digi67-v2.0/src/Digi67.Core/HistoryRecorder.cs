using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace Digi67.Core;

public sealed partial class HistoryRecorder(string directory, HistoryOptions options)
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    [GeneratedRegex(@"^\d{4}-\d{2}-\d{2}\.\d{4}\.jsonl$", RegexOptions.CultureInvariant)]
    private static partial Regex ManagedName();

    public async Task AppendAsync(HistoryRecord record, CancellationToken cancellationToken)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            Directory.CreateDirectory(directory);
            var date = record.Timestamp.UtcDateTime.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
            var files = ManagedFiles().Where(f => Path.GetFileName(f).StartsWith(date + ".", StringComparison.Ordinal)).Order().ToArray();
            var path = files.LastOrDefault() ?? Path.Combine(directory, date + ".0000.jsonl");
            var bytes = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(record, JsonDefaults.Options) + "\n");
            var cap = options.SegmentMegabytes * 1024L * 1024;
            if (bytes.Length > cap) throw new IOException("Single history record exceeds segment size.");
            if (File.Exists(path) && new FileInfo(path).Length + bytes.Length > cap)
            {
                var part = int.Parse(Path.GetFileName(path).Split('.')[1], System.Globalization.CultureInfo.InvariantCulture) + 1;
                if (part > 9999) throw new IOException("Too many history segments.");
                path = Path.Combine(directory, $"{date}.{part:0000}.jsonl");
            }
            await using (var stream = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read,
                             16384, FileOptions.Asynchronous | FileOptions.WriteThrough))
            {
                RepairIncompleteTail(stream);
                stream.Position = stream.Length;
                await stream.WriteAsync(bytes, cancellationToken);
                await stream.FlushAsync(cancellationToken);
                stream.Flush(flushToDisk: true);
            }
            Prune(record.Timestamp, path);
        }
        finally { _gate.Release(); }
    }

    // After power loss, only the unfinished final line is discarded. Complete records survive.
    private static void RepairIncompleteTail(FileStream stream)
    {
        if (stream.Length == 0) return;
        var position = stream.Length;
        var buffer = new byte[8192];
        while (position > 0)
        {
            var start = Math.Max(0, position - buffer.Length);
            stream.Position = start;
            var read = stream.Read(buffer, 0, (int)(position - start));
            for (var i = read - 1; i >= 0; i--)
                if (buffer[i] == (byte)'\n') { stream.SetLength(start + i + 1); return; }
            position = start;
        }
        stream.SetLength(0);
    }

    private string[] ManagedFiles() => Directory.Exists(directory)
        ? Directory.GetFiles(directory, "*.jsonl").Where(f => ManagedName().IsMatch(Path.GetFileName(f))).ToArray() : [];

    private void Prune(DateTimeOffset now, string activePath)
    {
        var cutoff = DateOnly.FromDateTime(now.UtcDateTime).AddDays(1 - options.RetentionDays);
        foreach (var path in ManagedFiles())
            if (path != activePath && DateOnly.TryParseExact(Path.GetFileName(path)[..10], "yyyy-MM-dd", out var date) && date < cutoff)
                File.Delete(path);
        var files = ManagedFiles().Select(f => new FileInfo(f)).OrderBy(f => f.Name, StringComparer.Ordinal).ToList();
        var size = files.Sum(f => f.Length);
        foreach (var file in files)
        {
            if (size <= options.MaxTotalMegabytes * 1024L * 1024) break;
            if (file.FullName == Path.GetFullPath(activePath)) continue;
            size -= file.Length;
            file.Delete();
        }
    }

    public async Task<HistoryPage> ReadAsync(DateOnly date, string? machine, int offset, int limit, CancellationToken cancellationToken)
    {
        if (offset < 0 || offset > 1000000 || limit is < 1 or > 500) throw new ArgumentOutOfRangeException(nameof(limit));
        await _gate.WaitAsync(cancellationToken);
        try
        {
            var prefix = date.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture) + ".";
            var rows = new List<HistoryRecord>();
            var skipped = 0;
            var invalid = 0;
            foreach (var path in ManagedFiles().Where(f => Path.GetFileName(f).StartsWith(prefix, StringComparison.Ordinal)).Order())
            {
                using var reader = new StreamReader(path, Encoding.UTF8);
                while (await reader.ReadLineAsync(cancellationToken) is { } line)
                {
                    HistoryRecord? row;
                    try { row = JsonSerializer.Deserialize<HistoryRecord>(line, JsonDefaults.Options); }
                    catch (JsonException) { invalid++; continue; }
                    if (row?.Changes is null) { invalid++; continue; }
                    if (!string.IsNullOrWhiteSpace(machine))
                    {
                        var changes = row.Changes.Where(c => c.Address.Equals(machine, StringComparison.OrdinalIgnoreCase)).ToArray();
                        if (changes.Length == 0) continue;
                        row = row with { Changes = changes };
                    }
                    if (skipped++ < offset) continue;
                    if (rows.Count == limit) return new(rows.ToArray(), offset + limit, invalid);
                    rows.Add(row);
                }
            }
            return new(rows.ToArray(), null, invalid);
        }
        finally { _gate.Release(); }
    }
}
