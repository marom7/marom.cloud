namespace Digi67.Core;

// Pure aggregation: independently testable, with no network or filesystem side effects.
public sealed class DigiCollector(EngineOptions options)
{
    public Snapshot Merge(CatalogLoad inventory, PingObservation[] ping, DigiFetch digi,
        Snapshot? previous, DateTimeOffset timestamp, long durationMs)
    {
        var previousMap = previous?.Machines.ToDictionary(m => m.Address, StringComparer.OrdinalIgnoreCase)
                          ?? new Dictionary<string, MachineResult>(StringComparer.OrdinalIgnoreCase);
        var pingMap = ping.ToDictionary(p => p.Address, StringComparer.OrdinalIgnoreCase);
        var machines = MachineCatalog.Flatten(inventory.Catalog);
        var identities = machines.Select(m => Identity.ForMachine(m.Address, options)).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var groups = digi.Readings.GroupBy(d => Identity.Normalize(d.DisplayName, options), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.ToArray(), StringComparer.OrdinalIgnoreCase);
        var ambiguous = groups.Where(g => g.Value.Length != 1).Select(g => g.Key).Order().ToArray();
        var unmatched = groups.Keys.Where(k => !identities.Contains(k)).Order().ToArray();
        var rows = machines.Select(m =>
        {
            pingMap.TryGetValue(m.Address, out var p);
            previousMap.TryGetValue(m.Address, out var old);
            var key = Identity.ForMachine(m.Address, options);
            groups.TryGetValue(key, out var matching);
            var status = digi.State switch
            {
                "disabled" => "disabled",
                "error" => old?.Digi is not null ? "stale" : "unavailable",
                _ => matching is null ? "missing" : matching.Length == 1 ? "current" : "ambiguous"
            };
            var reading = status == "current" ? matching![0] : status == "stale" ? old?.Digi : null;
            // Discard old association if the configured alias changed between runs.
            if (reading is not null && Identity.Normalize(reading.DisplayName, options) != key)
            {
                reading = null;
                status = "unavailable";
            }
            return new MachineResult
            {
                Address = m.Address, Category = m.Category, CategoryHe = m.CategoryHe,
                Connected = p?.Connected, PingMs = p?.Connected == true ? p.PingMs : null,
                PingStatus = p?.Status ?? "NotScanned", LastSeen = p?.Connected == true ? p.ObservedAt : old?.LastSeen,
                DigiStatus = status, Digi = reading
            };
        }).ToArray();
        var times = rows.Where(m => m.Connected == true && m.PingMs is not null).Select(m => m.PingMs!.Value).ToArray();
        return new Snapshot
        {
            CycleId = Guid.NewGuid().ToString("N"), Mode = options.Mode, Timestamp = timestamp,
            AgentName = options.IsDemo ? options.AgentName + " (DEMO)" : options.AgentName,
            CycleDurationMs = durationMs, StaleAfterSeconds = options.StaleAfterSeconds,
            Summary = new(rows.Length, rows.Count(m => m.Connected == true), rows.Count(m => m.Connected == false),
                rows.Count(m => m.Connected is null), times.Length == 0 ? null : Math.Round(times.Average(), 2)),
            Categories = inventory.Catalog.Categories.Select(c => new CategoryInfo(c.Key, c.Name, c.Icon, c.Color)).ToArray(),
            Machines = rows,
            Quality = new(inventory.State, inventory.ErrorCode, digi.State, digi.ErrorCode, unmatched, ambiguous)
        };
    }

    public static HistoryRecord Changes(Snapshot current, Snapshot? previous)
    {
        var before = previous?.Machines.ToDictionary(m => m.Address, StringComparer.OrdinalIgnoreCase)
                     ?? new Dictionary<string, MachineResult>(StringComparer.OrdinalIgnoreCase);
        var changes = new List<MachineChange>();
        foreach (var m in current.Machines)
        {
            if (!before.Remove(m.Address, out var old)) changes.Add(new(m.Address, "added", null, m));
            else if (m.Connected != old.Connected || m.PingStatus != old.PingStatus || m.DigiStatus != old.DigiStatus ||
                     m.Digi?.ActiveWan != old.Digi?.ActiveWan || m.Category != old.Category ||
                     m.Digi?.FirmwareVersion != old.Digi?.FirmwareVersion || m.Digi?.Id != old.Digi?.Id)
                changes.Add(new(m.Address, "changed", old.Connected, m));
        }
        changes.AddRange(before.Values.Select(m => new MachineChange(m.Address, "removed", m.Connected, null)));
        return new(current.CycleId, current.Timestamp, current.Mode, current.Summary, current.Quality, changes.ToArray());
    }
}
