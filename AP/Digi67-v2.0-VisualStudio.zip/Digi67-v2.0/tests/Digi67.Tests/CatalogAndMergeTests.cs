using System.Text.Json;
using Digi67.Core;
using Digi67.Engine;

namespace Digi67.Tests;

public class CatalogAndMergeTests
{
    [Fact]
    public void OriginalInventoryContains177MachinesInSixCategories()
    {
        var catalog = new MachineCatalog(Path.Combine(AppContext.BaseDirectory, "fixtures/machines.json"), TestData.Options()).Load();
        Assert.Equal(177, MachineCatalog.Flatten(catalog.Catalog).Length);
        Assert.Equal(6, catalog.Catalog.Categories.Length);
        Assert.Equal(new[] { 85, 21, 10, 8, 24, 29 }, catalog.Catalog.Categories.Select(c => c.Addresses.Length));
    }

    [Fact]
    public void BadHotReloadKeepsLastGoodThenRecovers()
    {
        using var temp = new TempFolder();
        var path = Path.Combine(temp.Path, "machines.json");
        File.WriteAllText(path, JsonSerializer.Serialize(TestData.Catalog("YT509"), JsonDefaults.Options));
        var catalog = new MachineCatalog(path, TestData.Options());
        Assert.Equal("current", catalog.Load().State);
        File.WriteAllText(path, "{incomplete");
        Assert.Equal("lastGood", catalog.Load().State);
        Assert.Single(MachineCatalog.Flatten(catalog.Load().Catalog));
        File.WriteAllText(path, JsonSerializer.Serialize(TestData.Catalog("YT509", "YT510"), JsonDefaults.Options));
        Assert.Equal(2, MachineCatalog.Flatten(catalog.Load().Catalog).Length);
        File.Delete(path);
        Assert.Equal("lastGood", catalog.Load().State);
    }

    [Theory]
    [InlineData("YT509", "yt509")]
    [InlineData("YT509", "YT509.ashdodport.co.il")]
    public void RejectsDuplicateMergeIdentities(string first, string second) =>
        Assert.Throws<InvalidDataException>(() => MachineCatalog.Validate(TestData.Catalog(first, second), TestData.Options()));

    [Theory]
    [InlineData("../escape")]
    [InlineData("host;command")]
    [InlineData("")]
    public void RejectsInvalidHosts(string host) => Assert.Throws<InvalidDataException>(() => MachineCatalog.Validate(TestData.Catalog(host), TestData.Options()));

    [Fact]
    public void MatchesNameCaseAndConfiguredDomainButNeverSubstring()
    {
        var report = TestData.Snapshot(digi: new("success", [TestData.Digi(" yt509.ASHDODPORT.CO.IL "), TestData.Digi("YT5099")], TestData.Now, null));
        Assert.Equal("current", report.Machines[0].DigiStatus);
        Assert.Equal(new[] { "YT5099" }, report.Quality.UnmatchedDigiNames);
    }

    [Fact]
    public void AliasSupportsDifferentRouterAndComputerNames()
    {
        var options = TestData.Options(); options.DigiAliases["pc01"] = "YQ821";
        var report = new DigiCollector(options).Merge(new(TestData.Catalog("pc01"), "current", null), [], new("success", [TestData.Digi("YQ821")], TestData.Now, null), null, TestData.Now, 1);
        Assert.Equal("current", report.Machines[0].DigiStatus);
        Assert.Null(report.Machines[0].Connected);
    }

    [Fact]
    public void DuplicateVendorNamesAreAmbiguousRatherThanLastWins()
    {
        var report = TestData.Snapshot(digi: new("success", [TestData.Digi(), TestData.Digi("yt509")], TestData.Now, null));
        Assert.Equal("ambiguous", report.Machines[0].DigiStatus);
        Assert.Null(report.Machines[0].Digi);
        Assert.Single(report.Quality.AmbiguousDigiNames);
    }

    [Fact]
    public void FailedApiKeepsExplicitlyStaleTelemetryAndSuccessfulAbsenceClearsIt()
    {
        var first = TestData.Snapshot();
        var failure = TestData.Snapshot(false, DigiFetch.Failed("http_401"), first, TestData.Now.AddMinutes(1));
        Assert.False(failure.Machines[0].Connected);
        Assert.Equal(first.Machines[0].LastSeen, failure.Machines[0].LastSeen);
        Assert.Equal("stale", failure.Machines[0].DigiStatus);
        Assert.Equal(TestData.Now, failure.Machines[0].Digi!.FetchedAt);
        var removed = TestData.Snapshot(false, new("success", [], TestData.Now, null), failure);
        Assert.Null(removed.Machines[0].Digi);
        Assert.Equal("missing", removed.Machines[0].DigiStatus);
    }

    [Fact]
    public void RouterDoesNotTurnOfflineComputerOnlineAndProbeErrorsAreUnknown()
    {
        Assert.False(TestData.Snapshot(false).Machines[0].Connected);
        var report = TestData.Snapshot(null);
        Assert.Equal(1, report.Summary.Unknown);
        Assert.Equal(0, report.Summary.Offline);
        Assert.Null(report.Machines[0].PingMs);
    }

    [Fact]
    public void RecordsTransitionsAndInventoryRemovalWithoutPingNoise()
    {
        var first = TestData.Snapshot();
        Assert.Single(DigiCollector.Changes(first, null).Changes);
        var same = TestData.Snapshot(previous: first, time: TestData.Now.AddMinutes(1));
        Assert.Empty(DigiCollector.Changes(same, first).Changes);
        var down = TestData.Snapshot(false, previous: same);
        Assert.Equal("changed", Assert.Single(DigiCollector.Changes(down, same).Changes).Kind);
        var replacement = TestData.Snapshot(address: "YT510");
        Assert.Contains(DigiCollector.Changes(replacement, first).Changes, c => c.Kind == "removed" && c.Address == "YT509");
    }

    [Fact]
    public void StaleOrFailedPersistenceReportsDegradedHealth()
    {
        var options = TestData.Options(); var state = new RuntimeState { Snapshot = TestData.Snapshot() };
        Assert.Equal(200, Health.Describe(state, options, TestData.Now).StatusCode);
        Assert.Equal(503, Health.Describe(state, options, TestData.Now.AddMinutes(5)).StatusCode);
        state.HistoryError = "history_write_failed";
        Assert.Equal(503, Health.Describe(state, options, TestData.Now).StatusCode);
        state.HistoryError = null; state.Snapshot = TestData.Snapshot(null);
        Assert.Equal(503, Health.Describe(state, options, TestData.Now).StatusCode);
    }

    [Theory]
    [InlineData(0, 3000, 20)]
    [InlineData(60, 0, 20)]
    [InlineData(60, 3000, 101)]
    public void InvalidTimingFailsStartup(int interval, int timeout, int batch)
    {
        var options = new EngineOptions { IntervalSeconds = interval, PingTimeoutMs = timeout, BatchSize = batch };
        Assert.Throws<InvalidDataException>(options.Validate);
    }

    [Fact]
    public void DemoRefusesLiveApiAndSharedWrites()
    {
        Assert.Throws<InvalidDataException>(new EngineOptions { DigiApi = new() { Enabled = true } }.Validate);
        Assert.Throws<InvalidDataException>(new EngineOptions { SharedFolder = "external" }.Validate);
        Assert.Throws<InvalidDataException>(new EngineOptions { EnableRadminLinks = true }.Validate);
        Assert.Throws<InvalidDataException>(new EngineOptions { BindAddress = "0.0.0.0" }.Validate);
    }
}
