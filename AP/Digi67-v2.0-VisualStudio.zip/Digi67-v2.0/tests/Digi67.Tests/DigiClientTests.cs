using System.Net;
using System.Text;
using Digi67.Core;

namespace Digi67.Tests;

public class DigiClientTests
{
    private static DigiApiOptions Options() => new() { Enabled = true, BaseUrl = "https://digi.test", TimeoutSeconds = 1 };
    private static HttpResponseMessage Json(string text, HttpStatusCode status = HttpStatusCode.OK) => new(status) { Content = new StringContent(text, Encoding.UTF8, "application/json") };
    private const string Item = "{\"display_name\":\"YT509\",\"id\":7,\"temperature\":{\"celsius\":42.5},\"last_seen_unixtime\":1794358800,\"router_type\":{\"firmware_version\":\"test-only\"}}";

    [Fact]
    public async Task ReadsPagedNestedTelemetryAndSendsRawTokenOnGetOnly()
    {
        var calls = new List<string>();
        using var http = new HttpClient(new StubHandler((r, _) =>
        {
            Assert.Equal(HttpMethod.Get, r.Method);
            Assert.Equal("unit-test-secret", Assert.Single(r.Headers.GetValues("Authorization")));
            calls.Add(r.RequestUri!.PathAndQuery);
            return Task.FromResult(Json(calls.Count == 1 ? "{\"results\":[" + Item + "],\"next\":\"?page=2\"}" : "{\"results\":[],\"next\":null}"));
        }));
        var result = await new DigiClient(http, Options(), _ => "unit-test-secret").FetchAsync(default);
        Assert.Equal("success", result.State);
        Assert.Equal(new[] { "/v1/router", "/v1/router?page=2" }, calls);
        var row = Assert.Single(result.Readings);
        Assert.Equal(42.5, row.TemperatureCelsius); Assert.Equal("7", row.Id);
        Assert.Equal("test-only", row.FirmwareVersion); Assert.Null(row.ActiveWan);
    }

    [Fact]
    public async Task DisabledOrMissingTokenMakesNoRequest()
    {
        using var http = new HttpClient(new StubHandler((_, _) => throw new Exception("Must not connect")));
        Assert.Equal("disabled", (await new DigiClient(http, new(), _ => null).FetchAsync(default)).State);
        Assert.Equal("missing_or_invalid_token", (await new DigiClient(http, Options(), _ => null).FetchAsync(default)).ErrorCode);
    }

    [Theory]
    [InlineData(401)]
    [InlineData(429)]
    [InlineData(500)]
    public async Task HttpErrorsDoNotExposeBodiesOrToken(int status)
    {
        using var http = new HttpClient(new StubHandler((_, _) => Task.FromResult(Json("secret diagnostic", (HttpStatusCode)status))));
        var result = await new DigiClient(http, Options(), _ => "unit-test-secret").FetchAsync(default);
        Assert.Equal($"http_{status}", result.ErrorCode); Assert.Empty(result.Readings);
        Assert.DoesNotContain("secret", System.Text.Json.JsonSerializer.Serialize(result));
    }

    [Theory]
    [InlineData("not JSON")]
    [InlineData("{\"results\":{}}")]
    [InlineData("{\"results\":[{\"id\":1}]}")]
    [InlineData("{\"results\":[{\"display_name\":\"A\",\"temperature\":{\"celsius\":\"hot\"}}]}")]
    public async Task MalformedResponsesFailAsOneBatch(string payload)
    {
        using var http = new HttpClient(new StubHandler((_, _) => Task.FromResult(Json(payload))));
        Assert.Equal("invalid_json_or_mapping", (await new DigiClient(http, Options(), _ => "test").FetchAsync(default)).ErrorCode);
    }

    [Theory]
    [InlineData("https://outside.test/steal")]
    [InlineData("http://digi.test/insecure")]
    [InlineData("/v1/router")]
    public async Task PaginationCannotLeakTokenOrLoop(string next)
    {
        var calls = 0;
        using var http = new HttpClient(new StubHandler((_, _) => { calls++; return Task.FromResult(Json("{\"results\":[" + Item + "],\"next\":\"" + next + "\"}")); }));
        var result = await new DigiClient(http, Options(), _ => "test").FetchAsync(default);
        Assert.Equal("error", result.State); Assert.Empty(result.Readings); Assert.Equal(1, calls);
    }

    [Fact]
    public async Task PageLimitRejectsPartialSuccess()
    {
        var options = Options(); options.MaxPages = 1;
        using var http = new HttpClient(new StubHandler((_, _) => Task.FromResult(Json("{\"results\":[" + Item + "],\"next\":\"?page=2\"}"))));
        var result = await new DigiClient(http, options, _ => "test").FetchAsync(default);
        Assert.Equal("error", result.State); Assert.Empty(result.Readings);
    }

    [Fact]
    public async Task ResponseSizeIsBounded()
    {
        var options = Options(); options.MaxResponseBytes = 1024;
        using var http = new HttpClient(new StubHandler((_, _) => Task.FromResult(Json(new string(' ', 2048)))));
        Assert.Equal("response_limit_or_invalid_pagination", (await new DigiClient(http, options, _ => "test").FetchAsync(default)).ErrorCode);
    }

    [Fact]
    public async Task RequestTimeoutBecomesErrorButShutdownCancellationPropagates()
    {
        using var http = new HttpClient(new StubHandler(async (_, ct) => { await Task.Delay(Timeout.Infinite, ct); return Json(""); }));
        var client = new DigiClient(http, Options(), _ => "test");
        Assert.Equal("timeout", (await client.FetchAsync(default)).ErrorCode);
        using var cts = new CancellationTokenSource(); cts.Cancel();
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => client.FetchAsync(cts.Token));
    }

    [Fact]
    public async Task ConfigurableRootArrayAndDetailsWork()
    {
        var options = Options(); options.ItemsPath = ""; options.NextPath = ""; options.DetailPath = "/v1/router/{id}";
        using var http = new HttpClient(new StubHandler((r, _) => Task.FromResult(Json(r.RequestUri!.AbsolutePath == "/v1/router" ? "[" + Item + "]" : Item))));
        var result = await new DigiClient(http, options, _ => "test").FetchAsync(default);
        Assert.Equal("success", result.State); Assert.Single(result.Readings);
    }

    [Fact]
    public async Task ChangedDetailIdentityFailsInsteadOfJoiningWrongRouter()
    {
        var options = Options(); options.DetailPath = "/v1/router/{id}";
        using var http = new HttpClient(new StubHandler((r, _) => Task.FromResult(Json(r.RequestUri!.AbsolutePath == "/v1/router" ? "{\"results\":[" + Item + "]}" : Item.Replace("YT509", "YT510", StringComparison.Ordinal)))));
        Assert.Equal("error", (await new DigiClient(http, options, _ => "test").FetchAsync(default)).State);
    }
}
