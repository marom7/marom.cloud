using System.Text.Json;
using Digi67.Core;
using Digi67.Engine;
using Microsoft.Extensions.Logging.Abstractions;

namespace Digi67.Tests;

public class EngineFailureTests
{
    private static async Task WaitFor(Func<bool> predicate)
    {
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));
        while (!predicate()) await Task.Delay(20, cts.Token);
    }

    [Fact]
    public async Task SharedPublisherOnlyWritesPilotFileAndLeavesLegacyResultsUntouched()
    {
        using var temp = new TempFolder();
        var legacy = Path.Combine(temp.Path, "results.json"); File.WriteAllText(legacy, "legacy-production-sentinel");
        var options = TestData.Options(); options.SharedFolder = temp.Path;
        var state = new RuntimeState();
        using var publisher = new SharedPublisher(options, state, NullLogger<SharedPublisher>.Instance);
        await publisher.StartAsync(default);
        var snapshot = TestData.Snapshot(); publisher.Enqueue(snapshot);
        await WaitFor(() => Volatile.Read(ref state.Share).State == "current");
        await publisher.StopAsync(default);
        Assert.Equal(snapshot.CycleId, (await AtomicJsonFile.ReadSnapshotAsync(Path.Combine(temp.Path, options.SharedFileName), "Live"))!.CycleId);
        Assert.Equal("legacy-production-sentinel", File.ReadAllText(legacy));
        Assert.Equal(snapshot.Timestamp, state.Share.SnapshotTimestamp);
    }

    [Fact]
    public async Task SharedFailureIsVisibleAndNextSnapshotRecovers()
    {
        using var temp = new TempFolder(); var options = TestData.Options();
        options.SharedFolder = Path.Combine(temp.Path, "not-mounted");
        var state = new RuntimeState();
        using var publisher = new SharedPublisher(options, state, NullLogger<SharedPublisher>.Instance);
        await publisher.StartAsync(default); publisher.Enqueue(TestData.Snapshot());
        await WaitFor(() => Volatile.Read(ref state.Share).State == "error");
        Assert.False(Directory.Exists(options.SharedFolder));
        Directory.CreateDirectory(options.SharedFolder); publisher.Enqueue(TestData.Snapshot());
        await WaitFor(() => Volatile.Read(ref state.Share).State == "current");
        await publisher.StopAsync(default);
    }

    [Fact]
    public void DelayedSharedSnapshotCannotLookFreshJustBecauseCopySucceededNow()
    {
        var options = TestData.Options(); options.SharedFolder = "configured";
        var state = new RuntimeState
        {
            Snapshot = TestData.Snapshot(),
            Share = new("current", TestData.Now, TestData.Now, null, TestData.Now.AddHours(-1))
        };
        Assert.Equal(503, Health.Describe(state, options, TestData.Now).StatusCode);
    }

    [Fact]
    public async Task DemoPublisherCannotWriteEvenWhenGivenLiveLookingPathsDirectly()
    {
        using var temp = new TempFolder();
        using var publisher = new SharedPublisher(new() { SharedFolder = temp.Path }, new(), NullLogger<SharedPublisher>.Instance);
        await publisher.StartAsync(default); publisher.Enqueue(TestData.Snapshot()); await publisher.StopAsync(default);
        Assert.Empty(Directory.GetFiles(temp.Path));
    }

    [Fact]
    public async Task HistoryDiskFailureStillPublishesSnapshotAndRecoversWithBaseline()
    {
        using var temp = new TempFolder();
        var options = new EngineOptions { DataDirectory = temp.Path, MachinesFile = Path.Combine(temp.Path, "machines.json") };
        File.WriteAllText(options.MachinesFile, JsonSerializer.Serialize(TestData.Catalog("YT509"), JsonDefaults.Options));
        var historyPath = Path.Combine(temp.Path, "history"); File.WriteAllText(historyPath, "obstruct-directory");
        var state = new RuntimeState();
        using var publisher = new SharedPublisher(options, state, NullLogger<SharedPublisher>.Instance);
        var history = new HistoryRecorder(historyPath, new());
        using var service = new CollectionService(options, new(options.MachinesFile, options), new(new DemoPingProbe(), 2, 1000),
            new DemoDigiSource(() => [new("YT509", "T", "T")]), new(options), history, state, publisher, NullLogger<CollectionService>.Instance);
        await service.RunOnceAsync(default);
        Assert.Equal("history_write_failed", state.HistoryError);
        Assert.True(File.Exists(Path.Combine(temp.Path, "results.json")));
        Assert.NotNull(state.Snapshot);
        File.Delete(historyPath);
        await service.RunOnceAsync(default);
        Assert.Null(state.HistoryError);
        var page = await history.ReadAsync(DateOnly.FromDateTime(DateTime.UtcNow), null, 0, 100, default);
        Assert.Single(Assert.Single(page.Records).Changes);
    }

    [Fact]
    public async Task LocalSnapshotFailureDoesNotPublishInMemorySuccess()
    {
        using var temp = new TempFolder();
        var options = new EngineOptions { DataDirectory = temp.Path, MachinesFile = Path.Combine(temp.Path, "machines.json") };
        File.WriteAllText(options.MachinesFile, JsonSerializer.Serialize(TestData.Catalog("YT509"), JsonDefaults.Options));
        Directory.CreateDirectory(Path.Combine(temp.Path, "results.json"));
        var state = new RuntimeState();
        using var publisher = new SharedPublisher(options, state, NullLogger<SharedPublisher>.Instance);
        using var service = new CollectionService(options, new(options.MachinesFile, options), new(new DemoPingProbe(), 2, 1000),
            new DemoDigiSource(() => []), new(options), new(Path.Combine(temp.Path, "history"), new()), state, publisher, NullLogger<CollectionService>.Instance);
        await Assert.ThrowsAnyAsync<IOException>(() => service.RunOnceAsync(default));
        Assert.Null(state.Snapshot); Assert.Equal("cycle_failed", state.CycleError);
    }
}
