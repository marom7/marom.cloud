using Digi67.Core;

namespace Digi67.Tests;

internal static class TestData
{
    public static readonly DateTimeOffset Now = DateTimeOffset.Parse("2026-11-11T01:00:00Z");
    public static EngineOptions Options() => new() { Mode = "Live" };
    public static Catalog Catalog(params string[] names) => new([new("TEST", "בדיקה", "", "#123456", names)]);
    public static DigiReading Digi(string name = "YT509") => new() { DisplayName = name, Id = "1", FetchedAt = Now, ActiveWan = "WiFi" };
    public static Snapshot Snapshot(bool? connected = true, DigiFetch? digi = null, Snapshot? previous = null, DateTimeOffset? time = null, string address = "YT509") =>
        new DigiCollector(Options()).Merge(new(Catalog(address), "current", null),
            [new(address, connected, connected == true ? 12 : null, connected == true ? "Success" : connected == false ? "TimedOut" : "ProbeError", time ?? Now)],
            digi ?? new("success", [Digi(address)], Now, null), previous, time ?? Now, 25);
}

internal sealed class TempFolder : IDisposable
{
    public string Path { get; } = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "digi67-tests-" + Guid.NewGuid().ToString("N"));
    public TempFolder() => Directory.CreateDirectory(Path);
    public void Dispose() { try { Directory.Delete(Path, true); } catch (IOException) { } }
}

internal sealed class StubHandler(Func<HttpRequestMessage, CancellationToken, Task<HttpResponseMessage>> send) : HttpMessageHandler
{
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken) => send(request, cancellationToken);
}
