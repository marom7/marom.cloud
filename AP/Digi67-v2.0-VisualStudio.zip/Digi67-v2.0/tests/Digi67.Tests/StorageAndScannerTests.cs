using System.Text.Json;
using Digi67.Core;

namespace Digi67.Tests;

public class StorageAndScannerTests
{
    private sealed class CountingProbe : IPingProbe
    {
        private int _active;
        public int Maximum;
        public async Task<PingObservation> ProbeAsync(string address, int timeoutMs, CancellationToken cancellationToken)
        {
            var current = Interlocked.Increment(ref _active);
            lock (this) Maximum = Math.Max(Maximum, current);
            try
            {
                await Task.Delay(15, cancellationToken);
                return new(address, true, 1, "Success", TestData.Now);
            }
            finally { Interlocked.Decrement(ref _active); }
        }
    }

    [Fact]
    public async Task Scans177MachinesWithBoundedConcurrencyAndStableOrder()
    {
        var probe = new CountingProbe();
        var machines = Enumerable.Range(0, 177).Select(i => new Machine("PC" + i, "T", "T")).ToArray();
        var result = await new PingScanner(probe, 20, 3000).ScanAsync(machines, default);
        Assert.Equal(177, result.Length); Assert.InRange(probe.Maximum, 2, 20);
        Assert.Equal(machines.Select(m => m.Address), result.Select(r => r.Address));
    }

    [Fact]
    public async Task ScanHonorsCancellation()
    {
        using var cts = new CancellationTokenSource(); cts.Cancel();
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => new PingScanner(new CountingProbe(), 2, 3000)
            .ScanAsync([new("PC1", "T", "T")], cts.Token));
    }

    [Fact]
    public async Task SnapshotPersistsLastSeenAcrossRestartAndRejectsMixedMode()
    {
        using var temp = new TempFolder(); var path = Path.Combine(temp.Path, "results.json");
        await AtomicJsonFile.WriteAsync(path, TestData.Snapshot());
        var restored = await AtomicJsonFile.ReadSnapshotAsync(path, "Live");
        var offline = TestData.Snapshot(false, previous: restored, time: TestData.Now.AddHours(1));
        Assert.Equal(TestData.Now, offline.Machines[0].LastSeen);
        await Assert.ThrowsAsync<InvalidDataException>(() => AtomicJsonFile.ReadSnapshotAsync(path, "Demo"));
    }

    [Fact]
    public async Task CancelledAtomicWritePreservesExistingSnapshotAndCleansTemp()
    {
        using var temp = new TempFolder(); var path = Path.Combine(temp.Path, "results.json");
        var original = TestData.Snapshot(); await AtomicJsonFile.WriteAsync(path, original);
        using var cts = new CancellationTokenSource(); cts.Cancel();
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => AtomicJsonFile.WriteAsync(path, TestData.Snapshot(false), cts.Token));
        Assert.Equal(original.CycleId, (await AtomicJsonFile.ReadSnapshotAsync(path, "Live"))!.CycleId);
        Assert.Empty(Directory.GetFiles(temp.Path, "*.tmp"));
    }

    [Fact]
    public async Task ConcurrentReadersNeverSeePartialJson()
    {
        using var temp = new TempFolder(); var path = Path.Combine(temp.Path, "results.json");
        await AtomicJsonFile.WriteAsync(path, TestData.Snapshot());
        var writing = Task.Run(async () => { for (var i = 0; i < 30; i++) await AtomicJsonFile.WriteAsync(path, TestData.Snapshot(i % 2 == 0)); });
        do
        {
            // FileShare.Delete permits same-directory replacement on Windows.
            await using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
            using var json = await JsonDocument.ParseAsync(file);
            Assert.Equal("2.0", json.RootElement.GetProperty("schemaVersion").GetString());
        } while (!writing.IsCompleted);
        await writing;
    }

    [Fact]
    public async Task HistoryRepairsInterruptedTailAndSupportsPagingAndMachineFilter()
    {
        using var temp = new TempFolder(); var history = new HistoryRecorder(temp.Path, new());
        var first = TestData.Snapshot(); await history.AppendAsync(DigiCollector.Changes(first, null), default);
        var path = Assert.Single(Directory.GetFiles(temp.Path, "*.jsonl"));
        await File.AppendAllTextAsync(path, "{\"partial\":");
        var second = TestData.Snapshot(false, previous: first); await history.AppendAsync(DigiCollector.Changes(second, first), default);
        var page = await history.ReadAsync(DateOnly.FromDateTime(TestData.Now.UtcDateTime), "yt509", 0, 1, default);
        Assert.Single(page.Records); Assert.Equal(1, page.NextOffset); Assert.Equal(0, page.InvalidLines);
        var last = await history.ReadAsync(DateOnly.FromDateTime(TestData.Now.UtcDateTime), "YT509", 1, 100, default);
        Assert.Single(last.Records); Assert.Null(last.NextOffset);
        Assert.Empty((await history.ReadAsync(DateOnly.FromDateTime(TestData.Now.UtcDateTime), "missing", 0, 100, default)).Records);
    }

    [Fact]
    public async Task RetentionOnlyDeletesOwnedHistoryFiles()
    {
        using var temp = new TempFolder(); var history = new HistoryRecorder(temp.Path, new() { RetentionDays = 2 });
        var unrelated = Path.Combine(temp.Path, "keep.jsonl"); File.WriteAllText(unrelated, "keep");
        var old = TestData.Snapshot(time: TestData.Now.AddDays(-3));
        await history.AppendAsync(DigiCollector.Changes(old, null), default);
        var current = TestData.Snapshot(); await history.AppendAsync(DigiCollector.Changes(current, old), default);
        Assert.True(File.Exists(unrelated));
        Assert.Single(Directory.GetFiles(temp.Path, "2026-*.jsonl"));
    }

    [Fact]
    public async Task SegmentRolloverAndByteCapKeepRecentOwnedFiles()
    {
        using var temp = new TempFolder();
        var history = new HistoryRecorder(temp.Path, new() { SegmentMegabytes = 1, MaxTotalMegabytes = 2 });
        for (var i = 0; i < 5; i++)
        {
            var current = TestData.Snapshot();
            current = current with { Machines = [current.Machines[0] with { CategoryHe = new string('x', 700000) }] };
            await history.AppendAsync(DigiCollector.Changes(current, null), default);
        }
        var files = Directory.GetFiles(temp.Path, "*.jsonl").Select(f => new FileInfo(f)).ToArray();
        Assert.True(files.Length > 1);
        Assert.True(files.Sum(f => f.Length) <= 2 * 1024 * 1024);
        Assert.Contains(files, f => f.Name.EndsWith(".0004.jsonl", StringComparison.Ordinal));
    }

    [Fact]
    public async Task HistoryReportsCorruptCompleteLinesAndRejectsInvalidQueryBounds()
    {
        using var temp = new TempFolder(); var history = new HistoryRecorder(temp.Path, new());
        var current = TestData.Snapshot(); await history.AppendAsync(DigiCollector.Changes(current, null), default);
        await File.AppendAllTextAsync(Assert.Single(Directory.GetFiles(temp.Path)), "garbled\n");
        var page = await history.ReadAsync(DateOnly.FromDateTime(TestData.Now.UtcDateTime), null, 0, 100, default);
        Assert.Equal(1, page.InvalidLines); Assert.Single(page.Records);
        await Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => history.ReadAsync(default, null, -1, 100, default));
    }
}
