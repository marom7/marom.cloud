#!/usr/bin/env python3
"""Black-box tests. Temporary Demo data only; optional ICMP checks loopback only."""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import tempfile
import time
from urllib import request, error

parser = argparse.ArgumentParser()
parser.add_argument('--dotnet', default='dotnet')
args = parser.parse_args()
ROOT = Path(__file__).resolve().parents[1]
DLL = ROOT / 'src/Digi67.Engine/bin/Release/net8.0/Digi67.Engine.dll'
assert DLL.is_file(), 'Build the solution in Release first.'
checks = []
skipped = []

def check(name, condition):
    assert condition, name
    checks.append(name)
    print('PASS ' + name, flush=True)

def wait_for(getter, predicate, timeout=20):
    deadline = time.monotonic() + timeout
    last = None
    while time.monotonic() < deadline:
        try:
            last = getter()
            if predicate(last):
                return last
        except (OSError, ValueError):
            pass
        time.sleep(0.1)
    raise AssertionError('Timed out; last=' + repr(last))

with tempfile.TemporaryDirectory(prefix='digi67-smoke-') as folder:
    work = Path(folder)
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    config = json.loads((ROOT / 'config/digi67-config.json').read_text())
    config.update(intervalSeconds=1, localPort=port)
    config_path = work / 'config.json'
    config_path.write_text(json.dumps(config))
    inventory_path = work / 'machines.json'
    shutil.copyfile(ROOT / 'config/machines.json', inventory_path)
    command = [args.dotnet, str(DLL), '--config', str(config_path)]
    log = open(work / 'engine.log', 'w+')
    process = subprocess.Popen(command, stdout=log, stderr=log)
    base = f'http://127.0.0.1:{port}'
    # Bypass environment HTTP proxies ONLY for these test requests to localhost.
    opener = request.build_opener(request.ProxyHandler({}))

    def fetch(path, method='GET'):
        req = request.Request(base + path, method=method)
        try:
            response = opener.open(req, timeout=2)
        except error.HTTPError as e:
            response = e
        with response:
            body = response.read().decode('utf-8')
            try:
                data = json.loads(body)
            except json.JSONDecodeError:
                data = body
            return response.status, data, dict(response.headers)

    try:
        status = wait_for(lambda: fetch('/api/status'), lambda r: r[0] == 200)
        report = status[1]
        check('Demo snapshot contains original 177 machines', report['mode'] == 'Demo' and report['summary']['total'] == 177)
        check('Six original categories preserved', len(report['categories']) == 6)
        check('Snapshot no-store response', status[2].get('Cache-Control') == 'no-store')
        check('Health ready', fetch('/api/health')[0] == 200)
        check('Dashboard and assets served', all(fetch(p)[0] == 200 for p in ['/', '/app.js', '/styles.css']))
        check('Inventory compatibility route', len(fetch('/machines.json')[1]['categories']) == 6)
        check('Radmin disabled by default', fetch('/api/ui-config')[1]['enableRadminLinks'] is False)
        check('Read-only API', fetch('/api/status', 'POST')[0] == 405)
        check('Private config is not served', fetch('/digi67-config.json')[0] == 404)
        check('Private history folder is not static', fetch('/data/demo/history')[0] == 404)
        check('History rejects path-like date', fetch('/api/history?date=../../etc')[0] == 400)
        history = fetch('/api/history?limit=1')[1]
        check('History contains initial state baseline', len(history['records'][0]['changes']) == 177)
        filtered = fetch('/api/history?machine=YT509')[1]
        check('History filters a machine', all(c['address'] == 'YT509' for row in filtered['records'] for c in row['changes']))
        collision = subprocess.run(command + ['--once'], capture_output=True, text=True, timeout=10)
        check('Second writer blocked', collision.returncode == 2)
        inventory_path.write_text('{unfinished')
        bad = wait_for(lambda: fetch('/api/health'), lambda r: r[1].get('quality', {}).get('catalogState') == 'lastGood')
        check('Invalid hot reload is degraded without dropping inventory', bad[0] == 503 and fetch('/api/status')[1]['summary']['total'] == 177)
        inventory = json.loads((ROOT / 'config/machines.json').read_text())
        inventory['categories'][0]['addresses'].pop()
        inventory_path.write_text(json.dumps(inventory))
        revised = wait_for(lambda: fetch('/api/status'), lambda r: r[1]['summary']['total'] == 176)
        check('Valid hot reload recovers and removes a machine', revised[1]['quality']['catalogState'] == 'current')
        check('New inventory available to client', sum(len(c['addresses']) for c in fetch('/machines.json')[1]['categories']) == 176)
    finally:
        if process.poll() is None:
            if os.name == 'nt':
                process.terminate()
            else:
                process.send_signal(signal.SIGINT)
            try:
                process.wait(timeout=12)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        log.seek(0)
        logs = log.read()
        log.close()
        if process.returncode not in (0, -15):
            print(logs)
    check('Engine shutdown releases the lock', process.returncode in (0, -15))
    before = json.loads((work / 'data/demo/results.json').read_text())
    restart = subprocess.run(command + ['--once'], capture_output=True, text=True, timeout=15)
    check('One-shot restart succeeds', restart.returncode == 0)
    after = json.loads((work / 'data/demo/results.json').read_text())
    check('Restart writes new complete snapshot', after['cycleId'] != before['cycleId'])
    (work / 'data/demo/results.json').write_text('{broken')
    recovery = subprocess.run(command + ['--once'], capture_output=True, text=True, timeout=15)
    check('Corrupt snapshot recovery keeps diagnostic copy', recovery.returncode == 0 and bool(list((work / 'data/demo').glob('results.json.corrupt-*'))))

    # No port network hosts: the only real ICMP destination in all verification is 127.0.0.1.
    config.update(mode='Live')
    config_path.write_text(json.dumps(config))
    inventory_path.write_text(json.dumps({'categories': [{'key': 'LOCAL', 'name': 'Loopback test', 'icon': '', 'color': '#123456', 'addresses': ['127.0.0.1']}]}))
    loopback = subprocess.run(command + ['--once'], capture_output=True, text=True, timeout=15)
    check('Live loopback-only scan completes', loopback.returncode == 0)
    live = json.loads((work / 'data/live/results.json').read_text())
    if live['machines'][0]['connected'] is True:
        check('ICMP loopback receives an actual reply', True)
    else:
        check('Unavailable ICMP is unknown instead of a crash or false offline',
              live['machines'][0]['connected'] is None and live['machines'][0]['pingStatus'] == 'ProbeError')
        skipped.append('Actual ICMP reply: host has no usable ICMP capability/ping utility; verify on Windows pilot.')
        print('SKIP ' + skipped[-1])
    check('Demo and Live data isolated', (work / 'data/demo/results.json').exists() and live['mode'] == 'Live')

print(json.dumps({'passed': len(checks), 'failed': 0, 'skipped': skipped, 'checks': checks}, ensure_ascii=False))
