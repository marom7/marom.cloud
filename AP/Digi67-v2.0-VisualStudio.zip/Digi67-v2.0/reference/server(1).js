// ═══════════════════════════════════════════════
//  digi67-receiver — turtle67
//  
//  POST /digi67/report   → writes results.json
//  GET  /digi67/*        → serves static files
//  
//  Route: api.67.codes/digi67/ → tunnel67 → localhost:3067
//
//  67CODES | JAM 2.0
// ═══════════════════════════════════════════════

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3067;
const PREFIX = '/digi67';
const PUBLIC = path.join(__dirname, 'public');
const RESULTS = path.join(PUBLIC, 'results.json');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.css': 'text/css',
  '.js': 'application/javascript',
  '.png': 'image/png',
  '.ico': 'image/x-icon'
};

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  const url = req.url.split('?')[0];

  // Must start with /digi67
  if (!url.startsWith(PREFIX)) {
    if (url === '/') {
      res.writeHead(302, { Location: `${PREFIX}/` });
      return res.end();
    }
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    return res.end('404');
  }

  // Strip prefix: /digi67/report → /report
  const route = url.slice(PREFIX.length) || '/';

  // ── POST /digi67/report ← agent pushes here ──
  if (req.method === 'POST' && route === '/report') {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      try {
        const json = Buffer.concat(chunks).toString('utf8');
        JSON.parse(json);

        const tmp = RESULTS + '.tmp';
        fs.writeFileSync(tmp, json, 'utf8');
        fs.renameSync(tmp, RESULTS);

        console.log(`${ts()} [POST] ${(json.length / 1024).toFixed(1)}KB → results.json`);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end('{"status":"ok"}');
      } catch (err) {
        console.error(`${ts()} [ERROR] ${err.message}`);
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(`{"error":"${err.message}"}`);
      }
    });
    return;
  }

  // ── GET /digi67/* → static files ──
  let filePath = route;

  if (filePath === '/' || filePath === '/index.html') {
    const ua = (req.headers['user-agent'] || '').toLowerCase();
    const mobile = /mobile|android|iphone|ipad|ipod/i.test(ua);
    filePath = mobile ? '/mobile.html' : '/index.html';
  }

  if (filePath === '/m' || filePath === '/m/') filePath = '/mobile.html';

  const fullPath = path.join(PUBLIC, filePath);

  if (!path.resolve(fullPath).startsWith(path.resolve(PUBLIC))) {
    res.writeHead(403); return res.end();
  }

  if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
    const ext = path.extname(fullPath);
    const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream' };

    if (fullPath.endsWith('results.json')) {
      headers['Cache-Control'] = 'no-cache, no-store';
    }

    res.writeHead(200, headers);
    res.end(fs.readFileSync(fullPath));
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('404');
  }
});

function ts() { return new Date().toLocaleTimeString('he-IL'); }

server.listen(PORT, () => {
  console.log(`
  ╔═════════════════════════════════════════╗
  ║  digi67-receiver — turtle67            ║
  ║  http://localhost:${PORT}                  ║
  ║                                         ║
  ║  POST ${PREFIX}/report  → results.json     ║
  ║  GET  ${PREFIX}/*       → public/          ║
  ║                                         ║
  ║  tunnel: api.67.codes${PREFIX}/            ║
  ╚═════════════════════════════════════════╝
  `);
});
