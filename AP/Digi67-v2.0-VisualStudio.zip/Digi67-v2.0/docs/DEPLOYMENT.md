# הוראות פריסה לפיילוט נפרד

המסמך מתאר פריסה עתידית. בזמן הכנת החבילה לא הותקן שירות, לא שונתה משימה מתוזמנת, לא נפתח firewall, לא עודכן שרת הייצור ולא נשלח דבר לרשת הנמל.

## 1. פיתוח ובדיקות

דרישות: Visual Studio 2022 17.11+ עם SDK ‎8.0.4xx, או SDK תואם בשורת פקודה. `global.json` מקבע את משפחת SDK 8.0.4xx ומאפשר תיקוני patch. דרושה גישה ל־NuGet בשחזור הראשוני של חבילות הבדיקות בלבד. חבילות המנוע אינן תלויות ב־NuGet חיצוני.

```powershell
dotnet restore Digi67.sln --locked-mode
dotnet build Digi67.sln -c Release -m:1
dotnet test Digi67.sln -c Release --no-build -m:1 --logger "trx;LogFileName=digi67-tests.trx" --results-directory TestResults
python tests/smoke.py
```

הבדיקה האחרונה משתמשת בקבצים זמניים וב־HTTP על loopback. ניסיון ICMP אמיתי יחיד נעשה ל־127.0.0.1; אם למארח אין יכולת ICMP, נבדק טיפול `unknown` ומדווח דילוג מפורש על אימות מענה אמיתי. אין בבדיקות כתובות מכונות מהנמל.

## 2. יצירת הפצה ל־Windows x64

ב־Visual Studio: Publish → Folder → הפרופיל `Windows-x64`. או:

```powershell
powershell -File scripts/Publish-Windows.ps1
```

נוצר פלט חדש תחת `artifacts/win-x64-<timestamp>`. ברירת המחדל self-contained כוללת runtime ולכן אינה דורשת התקנתו בתחנה, אך כן דורשת הורדת runtime packs בזמן הפרסום. הפרסום אינו single-file ואינו trimmed: יש להעביר את **כל התיקייה**, כולל `wwwroot`, הגדרות ורשימת מכונות.

הפצה קטנה התלויה ב־runtime מותקן:

```powershell
powershell -File scripts/Publish-Windows.ps1 -FrameworkDependent
```

במצב זה נדרש **ASP.NET Core Runtime 8 x64**, כולל Microsoft.NETCore.App ו־Microsoft.AspNetCore.App, בגרסה המאושרת באתר. ‎.NET Desktop Runtime לבדו אינו מספיק. יעד .NET 8 כבר אינו נתמך החל מ־10.11.2026; יש לקבוע שדרוג למסגרת נתמכת לפני קידום לפריסה תפעולית. מקורות Microsoft: [פרסום .NET](https://learn.microsoft.com/en-us/dotnet/core/deploying/), [תמיכה](https://dotnet.microsoft.com/en-us/platform/support/policy/dotnet-core).

## 3. בדיקת Demo בתחנה

העתק את הפלט לתיקייה חדשה, למשל `C:\Digi67-v2-Pilot\app`. אין להעתיק מעל התיקייה המקורית. הפעל:

```powershell
cd C:\Digi67-v2-Pilot\app
.\Digi67.Engine.exe --validate
.\Digi67.Engine.exe --once
.\Digi67.Engine.exe
```

פתח `http://127.0.0.1:8167/`. בדוק סימון Demo, 177 מחשבים, נתוני Digi סינתטיים בחלונית כלי ו־`/api/health`. עצירה ב־Ctrl+C. ההגדרות מחושבות יחסית למיקומן; אין להפעיל מתוך תיקייה מוגנת לכתיבה כגון Program Files בלי `dataDirectory` נפרד עם הרשאות מתאימות.

## 4. פיילוט Live מוגבל

1. שמור עותק תיקייה של גרסת הפיילוט הקודמת ושל הנתונים כשהמנוע עצור. אין צורך לשנות או לעצור את הייצור לשם ניסוי נפרד.
2. העתק את `config/digi67-live.example.json` ל־`C:\Digi67-v2-Pilot\digi67-pilot.local.json`.
3. צור רשימת `machines-pilot.json` עם התחנות שהוקצו לפיילוט בלבד, באותו מבנה קטגוריות. עדכן `machinesFile`. הקובץ עם 177 המכונות נשמר כמקור; לא מתחילים אוטומטית מסריקת כולן.
4. בחר `dataDirectory` ייעודי, למשל `C:\Digi67-v2-Pilot\state`. אל תכוון אותו לתיקיית ייצור. המנוע יוסיף `live` לשם התיקייה.
5. `mode=Live`; השאר `digiApi.enabled=false`, `sharedFolder=""`, `enableRadminLinks=false` בשלב Ping בלבד. עדכן `localPort` אם 8167 תפוס.
6. הרץ `--validate`, אחריו `--once`, ובדוק מול `ping.exe` ותחנה מוכרת. אי־מענה אינו בהכרח תקלה: בדוק DNS, מדיניות ICMP וחומת אש.
7. חבר Digi לפי [DIGI-API.md](DIGI-API.md), ואז חזור על בדיקת מחזור יחיד. אל תשתמש בנתוני ההדגמה לאימות החיבור.

דוגמה להפעלה מתמשכת אחרי השלמת ההגדרות:

```powershell
C:\Digi67-v2-Pilot\app\Digi67.Engine.exe --config C:\Digi67-v2-Pilot\digi67-pilot.local.json
```

מפתח ה־API נמסר למשתנה הסביבה של חשבון ההרצה; הוא אינו עובר לדפדפן. אין להכניסו לקובץ הקונפיג, לארגומנטים או לגיבוי הפרויקט. חסרון token או TLS שגוי מופיעים כמצב Digi לא זמין, עם המשך סריקת Ping.

## 5. העברה לשיתוף OT → IT

השתמש רק בנתיב השיתוף הקיים/המאושר באתר, ובתיקיית פיילוט נפרדת. לדוגמה, הזן נתיב UNC מוסכם ב־`sharedFolder`; הקוד אינו יוצר שיתוף ואינו משנה הרשאות. אין סקריפט לפתיחת נתיבי רשת.

- ברירת המחדל `sharedFileName=digi67-v2-results.json` מגינה מפני החלפה מקרית של הדוח המקורי.
- חשבון ההרצה צריך הרשאות create/write/rename/delete לקובץ הפיילוט בתיקייה. המנוע אינו מנסה ליצור תיקיית שיתוף חסרה.
- `--once` אינו מפעיל את worker השיתוף; בדיקתו דורשת מצב ההרצה המתמשך.
- השווה את הקובץ המקומי והעותק לפי `cycleId` ו־timestamp, ובדוק קריאת JSON בזמן כתיבה וניתוק/חיבור של השיתוף בפיילוט.
- בדוק `/api/health.share`: הצלחה אחרונה, ניסיון אחרון וחותמת זמן הדוח שהועתק.
- צרכן IT צריך לקרוא את קובץ הפיילוט החדש, לכבד `mode`, `connected=null` והתיישנות. **שרת Node/forwarder הייצורי לא שונה ולא הופעל מהחבילה.**

אין בחבילה POST ל־3050, ל־Cloudflare או לשירות חיצוני. אין מעבר של פקודות שליטה בין רשתות. ל־IT מותר לצרוך את הדוח רק דרך המסלול המאושר.

## 6. הפעלה אוטומטית לפיילוט

המנוע הוא יישום console/ASP.NET, **אינו שירות Windows SCM**. אין להתקין אותו באמצעות `sc.exe create` ללא התאמת Windows Service נפרדת.

הסקריפט הבא יוצר רק משימת פיילוט חדשה בעת כניסת המשתמש, בהרשאות רגילות. הוא מסרב להחליף משימה קיימת ואינו מפעיל אותה מיד:

```powershell
powershell -File scripts/Register-PilotTask.ps1 -PublishDirectory C:\Digi67-v2-Pilot\app -ConfigPath C:\Digi67-v2-Pilot\digi67-pilot.local.json -WhatIf
powershell -File scripts/Register-PilotTask.ps1 -PublishDirectory C:\Digi67-v2-Pilot\app -ConfigPath C:\Digi67-v2-Pilot\digi67-pilot.local.json
```

שם המשימה: `Digi67-v2-Pilot`. היא פועלת רק כשאותו משתמש מחובר. השירות/המשימה המקוריים אינם נקראים ואינם משתנים. ל־24/7 ללא logon נדרשת החלטת פריסה נוספת: חשבון שירות, זהות לשיתוף ו־Windows Service תקני, או מנגנון תפעול מאושר אחר. סקריפטי PowerShell ו־Task Scheduler דורשים בדיקת הרצה ב־Windows; אין לטעון שנבדקו על Windows מתוך בדיקות Linux.

## 7. נסיגה ואבחון

עצור רק את תהליך/משימת `Digi67-v2-Pilot`, ושמור את תיקיית `state` לאבחון. השבת/הסר את משימת הפיילוט דרך Task Scheduler אם נוצרה. חזור לעותק הפיילוט הקודם; אין צורך בשינוי מערכת הייצור שלא הוחלפה.

| תופעה | בדיקה |
|---|---|
| הקובץ לא מתחיל לרוץ | runtime תואם או הפצה self-contained, הרשאות תיקייה וקונפיג תקין |
| Startup/validation failed | JSON, רשימת מכונות, תיקייה ניתנת לכתיבה, תהליך נוסף עם אותה נעילה |
| פורט תפוס | שנה רק את פורט הפיילוט; אין לעצור שירות ייצור |
| ProbeError/unknown | DNS, הרשאות ICMP, יכולת Ping במערכת ההפעלה |
| Digi http_401/http_403 | token, scheme והרשאות קריאה |
| transport_or_tls_error | חיבור מורשה, CA ושם DNS התואם לתעודה |
| invalid_json_or_mapping | envelope, שמות שדות, יחידות ו־detail identity |
| history_write_failed | נפח דיסק והרשאות; snapshot ממשיך להישמר אם אפשר |
| shared_write_failed | נתיב UNC, חשבון ההרצה והרשאות replace; האיסוף ממשיך |
| הדוח מיושן | המנוע רץ? המחזור ארוך? שעונים מסונכרנים? בדוק cycleDurationMs וספי זמן |

קודי יציאה: 0 הצלחה; 2 שגיאת הגדרות/קלט/קבצים/אתחול; 3 מחזור `--once` הסתיים עם Digi/history/catalog degraded; 130 ביטול של `--once`. שגיאת ProbeError אינה הופכת את התהליך לכשל: היא מוצגת ב־summary.unknown. פרטי חריגה לא צפויה עדיין עשויים להופיע ב־stderr לצורך אבחון.
