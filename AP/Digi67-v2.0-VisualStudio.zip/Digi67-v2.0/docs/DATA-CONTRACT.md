# חוזה הנתונים וה־HTTP

ה־HTTP נקשר ל־loopback בלבד. כתובת ברירת מחדל: `http://127.0.0.1:8167`. כל התגובות כוללות `Cache-Control: no-store`. הנתיבים הבאים הם GET בלבד; אין API שמפעיל סריקה, מוחק היסטוריה או שולט בציוד.

| נתיב | תוצאה |
|---|---|
| `/` | הממשק המקומי |
| `/api/status`, `/results.json` | תמונת המצב האחרונה; 503 עד למחזור ראשון |
| `/api/machines`, `/machines.json` | רשימת המכונות התקינה האחרונה, במבנה categories/addresses המקורי |
| `/api/ui-config` | מצב, סף התיישנות והאם קישורי Radmin מותרים |
| `/api/health` | 200 תקין; 503 ממתין, מיושן או degraded; גוף JSON בכל מצב |
| `/api/history?date=2026-11-11&limit=100&offset=0` | היסטוריית יום **UTC** |
| `/api/history?date=2026-11-11&machine=YT509` | רק מחזורים שבהם נרשם מעבר/בסיס לאותה מכונה |

`date` ברירת מחדל היום UTC. `limit` בין 1 ל־500. `offset` בין 0 ל־1,000,000. קלט תאריך לא תקין מחזיר 400. `nextOffset` הוא המיקום לדף הבא או null. דפדוף נעשה על הנתונים הקיימים ברגע הקריאה; מחיקה עקב retention בין דפים יכולה להזיז offsets. `invalidLines` מונה שורות פגומות שנפגשו עד סוף הקריאה הנוכחית.

## תמונת מצב 2.0

דוגמת מבנה סינתטית של מכונה אחת, לא נתון מהנמל:

```json
{
  "schemaVersion": "2.0",
  "cycleId": "demo-cycle-example",
  "mode": "Demo",
  "timestamp": "2026-11-11T01:00:00Z",
  "agentName": "Digi67-v2-Pilot (DEMO)",
  "cycleDurationMs": 25,
  "staleAfterSeconds": 180,
  "summary": { "total": 1, "online": 0, "offline": 1, "unknown": 0, "averagePingMs": null },
  "categories": [{ "key": "GORERIM", "name": "גוררים", "icon": "🚛", "color": "#5c9bff" }],
  "machines": [{
    "address": "YT509",
    "category": "GORERIM",
    "categoryHe": "גוררים",
    "connected": false,
    "pingMs": null,
    "pingStatus": "TimedOut",
    "lastSeen": "2026-11-11T00:59:00Z",
    "digiStatus": "stale",
    "digi": {
      "displayName": "YT509",
      "id": "DEMO-1",
      "fetchedAt": "2026-11-11T00:59:00Z",
      "routerLastSeen": "2026-11-11T00:58:00Z",
      "temperatureCelsius": 39,
      "activeWan": "WiFi (DEMO)"
    }
  }],
  "quality": {
    "catalogState": "current",
    "catalogError": null,
    "digiState": "error",
    "digiError": "http_401",
    "unmatchedDigiNames": [],
    "ambiguousDigiNames": []
  }
}
```

## תאימות לממשק הקודם

השדות `timestamp`, `agentName`, `cycleDurationMs`, `summary`, `categories`, `machines`, `address`, `category`, `categoryHe`, `connected`, `pingMs`, `lastSeen` נשמרו. נוספו שדות, ו־`connected` הורחב מ־boolean ל־boolean/null כדי לבטא בדיקה שלא הצליחה לקבוע מצב. לכן **הצרכן הישן אינו תואם לחלוטין מבחינה סמנטית**: קוד שמתייחס לכל ערך falsy כ״מנותק״ דורש התאמה עבור null ועבור `mode: Demo`.

הממשק המצורף כבר מותאם. אין להעביר דוחות Demo ל־receiver המקורי או להחליף בייצור את `results.json` ללא בדיקת הצרכן. הנתיב בשיתוף נפרד כברירת מחדל. timestamp ישן מ־`staleAfterSeconds`, או עתידי ביותר מ־60 שניות, מוצג בממשק כמצב לא ידוע. הנתונים הגולמיים ב־API עדיין ניתנים לקריאה עם חותמת הזמן; צרכנים אחרים צריכים לבדוק אותה.

`lastSeen` מתייחס למענה Ping האחרון של המחשב. `routerLastSeen` מגיע מהספק ואינו אותו אירוע. `fetchedAt` הוא זמן שליפת המידע; `digiStatus: current` אומר שהקריאה הצליחה, לא בהכרח שהנתב עצמו דיווח עכשיו. יש לבחון גם `routerLastSeen` כאשר ה־API מספק אותו.

| `digiStatus` | פירוש |
|---|---|
| `current` | קיימת התאמה אחת בנתונים שנשלפו במחזור |
| `missing` | השליפה הצליחה אך לא נמצאה התאמה |
| `disabled` | החיבור כבוי; לא נשמרת טלמטריה קודמת כאילו החיבור פועל |
| `stale` | השליפה נכשלה ונשמר מידע קודם, עם חותמת הזמן המקורית |
| `unavailable` | השליפה נכשלה ואין מידע קודם מתאים |
| `ambiguous` | יותר מנתב אחד עם אותו שם מנורמל; לא בוצע מיזוג |

## היסטוריה

קבצים: `data/<demo|live>/history/YYYY-MM-DD.0000.jsonl`. כל שורה היא אובייקט JSON עצמאי:

```json
{
  "cycleId": "...",
  "timestamp": "2026-11-11T01:00:00Z",
  "mode": "Demo",
  "summary": { "total": 177, "online": 150, "offline": 27, "unknown": 0, "averagePingMs": 24 },
  "quality": { "catalogState": "current", "catalogError": null, "digiState": "success", "digiError": null, "unmatchedDigiNames": [], "ambiguousDigiNames": [] },
  "changes": [{ "address": "YT509", "kind": "changed", "previousConnected": true, "current": { "address": "YT509", "connected": false } }]
}
```

`current` בדוגמה מקוצר; בקובץ האמיתי הוא אובייקט MachineResult מלא. `kind` הוא `added`, `changed` או `removed`; בהסרה `current=null`. baseline בתחילת תהליך/יום משתמש ב־`added` כדי להציג את כל המצב הידוע, גם עבור כלים שהיו במערכת קודם.

מעבר נרשם כשמשתנים מצב Ping, תוצאת Ping, מצב Digi, WAN פעיל, קטגוריה, מזהה נתב או קושחה. שינוי טמפרטורה/latency בלבד אינו יוצר אירוע; averagePingMs נשמר בסיכום כל מחזור. זהו יומן מעברים וסיכומי מחזורים, **לא ארכיון מלא של כל מדידה**. הוא אינו מאפשר להסיק זמינות בזמן שהמנוע לא פעל. retention ונפח עשויים להסיר baseline ישן — אין לשחזר ממנו מצבים חסרים כאילו נמדדו.

השעות בקבצים הן UTC; הממשק מציג לפי אזור הזמן של תחנת המשתמש. בסביבת הנמל יש להגדיר את תחנות התצוגה לפי Asia/Jerusalem/Israel בהתאם למדיניות הקיימת.
