[CmdletBinding()]
param([switch]$FrameworkDependent)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$output = Join-Path $projectRoot ('artifacts\win-x64-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
Push-Location $projectRoot
try {
    $selfContained = if ($FrameworkDependent) { 'false' } else { 'true' }
    dotnet publish src/Digi67.Engine/Digi67.Engine.csproj -c Release -r win-x64 --self-contained $selfContained -o $output -m:1
    if ($LASTEXITCODE -ne 0) { throw 'Publish failed' }
    Write-Host "Published to $output"
    Write-Host 'Default config is Demo. No service, task, firewall or production setting was changed.'
} finally { Pop-Location }
