[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$configPath = Join-Path $projectRoot 'config\digi67-config.json'
$config = Get-Content -Raw -LiteralPath $configPath | ConvertFrom-Json
if ($config.mode -ne 'Demo') { throw 'Start-Demo requires mode=Demo.' }
Push-Location $projectRoot
try {
    dotnet run --project src/Digi67.Engine/Digi67.Engine.csproj -c Release --no-launch-profile -- --config $configPath
    if ($LASTEXITCODE -ne 0) { throw 'Engine stopped with an error.' }
} finally { Pop-Location }
