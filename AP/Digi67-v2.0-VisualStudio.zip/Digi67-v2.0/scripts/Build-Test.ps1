[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
Push-Location $projectRoot
try {
    dotnet restore Digi67.sln --locked-mode
    if ($LASTEXITCODE -ne 0) { throw 'Restore failed' }
    dotnet build Digi67.sln -c Release --no-restore -m:1
    if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
    dotnet test Digi67.sln -c Release --no-build -m:1 --logger 'trx;LogFileName=digi67-tests.trx' --results-directory TestResults
    if ($LASTEXITCODE -ne 0) { throw 'Tests failed' }
} finally { Pop-Location }
