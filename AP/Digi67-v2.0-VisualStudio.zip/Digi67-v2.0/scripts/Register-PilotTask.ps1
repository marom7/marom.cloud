[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)][string]$PublishDirectory,
    [Parameter(Mandatory)][string]$ConfigPath
)
$ErrorActionPreference = 'Stop'
$taskName = 'Digi67-v2-Pilot'
$publishRoot = (Resolve-Path -LiteralPath $PublishDirectory).Path
$configFile = (Resolve-Path -LiteralPath $ConfigPath).Path
$exe = Join-Path $publishRoot 'Digi67.Engine.exe'
if (!(Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Publish Windows-x64 first.' }
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) { throw 'Pilot task already exists; no task was replaced.' }
& $exe --config $configFile --validate
if ($LASTEXITCODE -ne 0) { throw 'Configuration validation failed.' }
$user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$action = New-ScheduledTaskAction -Execute $exe -Argument ('--config "' + $configFile + '"') -WorkingDirectory $publishRoot
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
if ($PSCmdlet.ShouldProcess($taskName, 'Register a new pilot-only task at user logon')) {
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings | Out-Null
    Write-Host 'Pilot task registered; not started. It runs only while this user is logged on.'
}
