'use strict';
// DIGI67 dashboard — Vanilla JavaScript, DOM-safe rendering, no dependencies.
// "DEMO" is always clearly marked and never writes to the receiver/API.
const $ = id => document.getElementById(id);
const STALE_AFTER_MS = 180_000;
const POLL_MS = 10_000;
let uiConfig = { enableRadminLinks: false, staleAfterSeconds: 180 };
let engineHealth = null;
const state = {
  categories: [], inventory: [], report: null, demo: new URLSearchParams(location.search).get('demo') === '1',
  selectedCategory: null, filter: 'all', search: '', list: false, lastError: null, openMachine: null
};
const numberFmt = new Intl.NumberFormat('he-IL');
function make(tag, css, text) {
  const e = document.createElement(tag);
  if (css) e.className = css;
  if (text !== undefined) e.textContent = String(text);
  return e;
}
function setText(id, val) { $(id).textContent = String(val); }
function shortAddress(address) { return address.replace(/\.ashdodport\.co\.il$/i, ''); }
function formatTime(input, withDate = false) {
  if (!input) return '—';
  const date = new Date(input);
  if (!Number.isFinite(date.getTime())) return '—';
  const opts = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
  if (withDate) Object.assign(opts, { day: '2-digit', month: '2-digit', year: 'numeric' });
  return date.toLocaleString('he-IL', opts);
}
function elapsed(ts) {
  const ms = Date.now() - Date.parse(ts);
  if (!Number.isFinite(ms)) return 'לא ידוע';
  if (ms < 0) return 'שעון המקור מקדים';
  if (ms < 60_000) return `לפני ${Math.floor(ms / 1000)} שניות`;
  return `לפני ${Math.floor(ms / 60_000)} דקות`;
}
function isReportFresh(report) {
  const ts = report?.timestamp;
  const t = Date.parse(ts);
  return Number.isFinite(t) && (Date.now() - t) >= -60_000 && (Date.now() - t) <= (report.staleAfterSeconds || uiConfig.staleAfterSeconds) * 1000;
}
function hashCode(s) { let n = 5381; for (let i = 0; i < s.length; i++) n = ((n << 5) + n + s.charCodeAt(i)) | 0; return n >>> 0; }
function mockReport() {
  const now = new Date().toISOString();
  return {
    timestamp: now, agentName: 'DEMO ONLY', cycleDurationMs: 8920,
    machines: state.inventory.map(item => {
      const hash = hashCode(item.address);
      const connected = hash % 11 < 8;
      return { address: item.address, category: item.category, categoryHe: item.categoryHe,
        connected, pingMs: connected ? 6 + (hash % 84) : null, lastSeen: connected ? now : null };
    })
  };
}
function derive() {
  const demoReport = state.demo ? mockReport() : null;
  const report = demoReport || state.report;
  const fresh = !!report && isReportFresh(report);
  const map = new Map(report ? report.machines.map(item => [item.address.toLowerCase(), item]) : []);
  const machines = state.inventory.map(item => {
    const result = map.get(item.address.toLowerCase());
    const status = !fresh || !result || result.connected == null ? 'unknown' : result.connected ? 'online' : 'offline';
    return { ...item, status, pingMs: result?.pingMs ?? null, lastSeen: result?.lastSeen ?? null, digi: result?.digi ?? null, digiStatus: !fresh ? 'stale' : result?.digiStatus || 'missing' };
  });
  const online = machines.filter(m => m.status === 'online');
  const offline = machines.filter(m => m.status === 'offline');
  const unknown = machines.length - online.length - offline.length;
  const pings = online.filter(m => m.pingMs !== null).map(m => Number(m.pingMs)).filter(Number.isFinite);
  const avg = pings.length ? pings.reduce((a,b) => a + b, 0) / pings.length : null;
  return { machines, report, fresh, online: online.length, offline: offline.length,
    unknown, average: avg, total: machines.length, demo: state.demo || report?.mode === 'Demo' };
}
function categoryOf(key) { return state.categories.find(c => c.key === key); }
function toast(message) {
  const node = $('toast');
  node.textContent = message;
  node.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.remove('show'), 3200);
}
async function jsonFetch(url) {
  const response = await fetch(url, { cache: 'no-store' });
  if (!response.ok) throw new Error(`${url}: HTTP ${response.status}`);
  return response.json();
}
async function refresh() {
  $('refreshBtn').disabled = true;
  try {
    {
      try { uiConfig = await jsonFetch('api/ui-config'); } catch { uiConfig.enableRadminLinks = false; }
      try { engineHealth = await (await fetch('api/health', { cache: 'no-store' })).json(); } catch { engineHealth = null; }
      const catalog = await jsonFetch('machines.json');
      if (!catalog || !Array.isArray(catalog.categories)) throw new Error('Invalid machines.json');
      state.categories = catalog.categories;
      state.inventory = catalog.categories.flatMap(c => c.addresses.map(address => ({
        address, category: c.key, categoryHe: c.name, icon: c.icon
      })));
    }
    try {
      const data = await jsonFetch('results.json');
      if (Array.isArray(data.machines) && typeof data.timestamp === 'string') {
        state.report = data;
        state.lastError = null;
      } else {
        state.lastError = 'מבנה הדוח אינו תקין';
      }
    } catch (err) {
      // A missing results.json is expected before the first OT->IT report.
      state.lastError = err.message;
    }
    render();
  } catch (err) {
    state.lastError = err.message;
    setText('freshnessTitle', 'לא ניתן לקרוא את רשימת הכלים');
    setText('freshnessDescription', 'בדוק שהשרת פעיל וש־machines.json נמצא בתיקייה המתאימה');
    toast('טעינת inventory נכשלה');
  } finally { $('refreshBtn').disabled = false; }
}
function updateSource(d) {
  const pill = $('sourcePill');
  pill.className = 'source-pill';
  let title, desc, statusText, notice;
  if (d.demo) {
    pill.classList.add('demo'); statusText = 'מצב הדגמה';
    title = 'DEMO — נתונים סינתטיים בלבד';
    desc = 'התוצאות במסך מיוצרות מקומית להמחשת העיצוב; אינן מייצגות את רשת הנמל';
    notice = 'מצב הדגמה פעיל · אין תקשורת עם מחשבי OT';
  } else if (d.fresh) {
    pill.classList.add('live'); statusText = 'דיווח עדכני';
    title = 'דיווח עדכני ממנוע הניטור';
    desc = `${d.total} מחשבים ברשימה · הדוח התקבל ${elapsed(d.report.timestamp)}`;
    notice = 'סטטוסים מבוססים על דוח Ping אחרון';
  } else if (d.report) {
    pill.classList.add('stale'); statusText = 'נתונים לא עדכניים';
    title = 'הדוח האחרון התיישן — הסטטוסים אינם ידועים';
    desc = `דיווח אחרון: ${formatTime(d.report.timestamp, true)} · ${elapsed(d.report.timestamp)}`;
    notice = 'נדרש דוח חדש לפני שנציג מחובר / מנותק';
  } else {
    statusText = 'ממתין לנתונים';
    title = 'ממתינים לדיווח ראשון';
    desc = state.lastError && !state.lastError.includes('404') ?
      'לא התקבל דוח תקין מ־results.json' : 'הרשימה נטענה; טרם התקבל דוח ממנוע הסריקה';
    notice = 'רשימת ציוד זמינה · סטטוסים טרם ידועים';
  }
  setText('sourceText', statusText);
  setText('freshnessTitle', title);
  setText('freshnessDescription', desc);
  setText('heroNotice', notice);
  setText('eyebrowStatus', d.demo ? 'SIMULATION / DEMO ONLY' : 'NETWORK MONITORING');
  setText('demoBtn', d.demo ? 'כבה הדגמה' : 'הפעל הדגמה');
  setText('updatedAt', d.report ? formatTime(d.report.timestamp) : '—');
  setText('cycleTime', Number.isFinite(d.report?.cycleDurationMs) ? `${(d.report.cycleDurationMs / 1000).toFixed(1)}s` : '—');
  setText('agentName', d.report?.agentName || '—');
  const q = engineHealth?.quality;
  const issues = [];
  if (engineHealth?.unknownMachines > 0) issues.push(`${engineHealth.unknownMachines} בדיקות Ping לא קבעו מצב`);
  if (q?.digiState === 'error') issues.push('Digi API לא זמין — נתונים קודמים מסומנים כמיושנים');
  if (q?.catalogState === 'lastGood') issues.push('שגיאה ברשימת הכלים — מוצגת הרשימה התקינה האחרונה');
  if (engineHealth?.historyError) issues.push('שמירת ההיסטוריה נכשלה');
  if (engineHealth?.share?.state === 'error') issues.push('העברת הדוח לשיתוף נכשלה');
  if (engineHealth?.cycleError) issues.push('מחזור הניטור נכשל');
  if (q?.ambiguousDigiNames?.length) issues.push('נמצאו שמות Digi כפולים — לא בוצע שיוך אוטומטי');
  setText('engineHealth', issues.join(' · ') || (engineHealth?.status === 'healthy' ? 'המנוע פעיל' : 'ממתין לאימות מצב המנוע')); 
}
function renderMetrics(d) {
  setText('totalCount', numberFmt.format(d.total));
  setText('onlineCount', d.fresh ? d.online : '—');
  setText('offlineCount', d.fresh ? d.offline : '—');
  setText('onlineRatio', d.fresh && d.total ? `${Math.round(100 * d.online / d.total)}% מכלל המחשבים` : 'אין מידע עדכני');
  setText('offlineRatio', d.fresh && d.total ? `${Math.round(100 * d.offline / d.total)}% ללא מענה` : 'אין מידע עדכני');
  setText('pingAvg', d.average === null ? '—' : d.average.toFixed(0));
  setText('latencyText', d.average === null ? 'אין זמני תגובה' : `לפי ${d.online} תחנות שענו`);
}
function renderCategories(d) {
  const grid = $('categoryGrid'); grid.replaceChildren();
  for (const cat of state.categories) {
    const members = d.machines.filter(m => m.category === cat.key);
    const online = members.filter(m => m.status === 'online').length;
    const known = members.filter(m => m.status !== 'unknown').length;
    const card = make('button', 'category-card' + (state.selectedCategory === cat.key ? ' selected' : ''));
    card.type = 'button'; card.setAttribute('aria-pressed', String(state.selectedCategory === cat.key));
    card.style.setProperty('--cat-color', /^#[0-9A-Fa-f]{6}$/.test(cat.color || '') ? cat.color : '#66cfff');
    const icon = make('div', 'category-icon', cat.icon || '▦');
    const body = make('div', 'category-body');
    body.appendChild(make('div', 'category-title', cat.name));
    body.appendChild(make('div', 'category-sub', d.fresh ? `${online} מחוברים מתוך ${members.length}` : `${members.length} תחנות · אין נתוני חיבור`));
    const bar = make('div', 'category-progress');
    const fill = make('span'); fill.style.width = known ? `${Math.round(100 * online / members.length)}%` : '0%';
    bar.appendChild(fill);body.appendChild(bar);
    const count = make('div', 'category-num', members.length);
    count.appendChild(make('small', '', 'UNITS'));
    card.append(icon, body, count);
    card.addEventListener('click', () => {
      state.selectedCategory = state.selectedCategory === cat.key ? null : cat.key;
      render(); $('fleet').scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    grid.appendChild(card);
  }
}
function filterMachines(d) {
  const term = state.search.trim().toLowerCase();
  return d.machines.filter(m => (!state.selectedCategory || m.category === state.selectedCategory) &&
    (state.filter === 'all' || m.status === state.filter) &&
    (!term || m.address.toLowerCase().includes(term) || (m.categoryHe || '').toLowerCase().includes(term)));
}
const STATUS_TEXT = { online: 'מחובר', offline: 'לא הגיב', unknown: 'לא ידוע' };
function renderMachines(d) {
  const filtered = filterMachines(d);
  const grid = $('machineGrid'); grid.replaceChildren();
  grid.classList.toggle('list-layout', state.list);
  setText('visibleCount', `${filtered.length} מתוך ${d.total} יחידות`);
  $('emptyState').hidden = filtered.length !== 0;
  // Fragment avoids repetitive layout calculations with 177 machines.
  const fragment = document.createDocumentFragment();
  for (const m of filtered) {
    const btn = make('button', `machine-card ${m.status}`);
    btn.type = 'button';
    btn.setAttribute('aria-label', `${m.address}, ${STATUS_TEXT[m.status]}, הצג פרטים`);
    const head = make('div', 'machine-head');
    head.append(make('span', 'machine-indicator'), make('span', 'machine-name', shortAddress(m.address)));
    const name = make('div', 'machine-desc', m.categoryHe);
    const bottom = make('div', 'machine-bottom');
    bottom.append(make('span', '', STATUS_TEXT[m.status]));
    bottom.append(make('span', '', m.status === 'online' && m.pingMs !== null ? `${Math.round(m.pingMs)} ms` : '—'));
    btn.append(head, name, bottom);
    btn.addEventListener('click', () => openDrawer(m, d));
    fragment.appendChild(btn);
  }
  grid.appendChild(fragment);
}
function render() {
  const d = derive();
  updateSource(d); renderMetrics(d); renderCategories(d); renderMachines(d);
  if (state.openMachine) {
    const replacement = d.machines.find(m => m.address === state.openMachine);
    if (replacement) updateDrawer(replacement, d);
  }
}
function updateDrawer(m, d) {
  const category = categoryOf(m.category);
  setText('detailIcon', category?.icon || '▦');
  setText('detailCategory', m.categoryHe || m.category);
  setText('detailTitle', shortAddress(m.address));
  setText('detailStatus', STATUS_TEXT[m.status]);
  setText('detailAddress', m.address);
  setText('detailPing', m.status === 'online' && m.pingMs != null ? `${m.pingMs} ms` : '—');
  setText('detailTime', d.report ? formatTime(d.report.timestamp, true) : '—');
  setText('detailSource', d.demo ? 'הדגמה בלבד' : (d.fresh ? d.report.agentName || 'Agent' : 'לא עדכני'));
  $('detailStatus').className = 'detail-status ' + m.status;
  const a = $('radminLink');
  setText('detailLastSeen', formatTime(m.lastSeen, true));
  const digiStates = { current: 'עדכני', missing: 'ללא התאמה', stale: 'מיושן', disabled: 'כבוי', unavailable: 'לא זמין', ambiguous: 'שם כפול' };
  setText('detailDigiState', digiStates[m.digiStatus] || 'לא ידוע');
  const telemetry = m.digi;
  setText('detailDigi', telemetry ? `WAN: ${telemetry.activeWan || 'לא ידוע'} · טמפ׳: ${telemetry.temperatureCelsius ?? '—'}°C · קושחה: ${telemetry.firmwareVersion || '—'}` : 'אין נתוני Digi');
  setText('detailDigiTime', formatTime(telemetry?.fetchedAt, true));
  $('historyLink').href = `api/history?machine=${encodeURIComponent(m.address)}&limit=100`;
  const validHost = uiConfig.enableRadminLinks === true && !d.demo && /^[A-Za-z0-9.-]+$/.test(m.address) && m.address.length <= 253;
  a.classList.toggle('disabled', !validHost);
  a.href = validHost ? `radmin67://${m.address}` : '#';
  a.setAttribute('aria-disabled', String(!validHost));
  a.onclick = e => {
    if (!validHost) { e.preventDefault(); return; }
    toast('הקישור ייפתח רק בתחנה עם מטפל radmin67:// והרשאות רשת מתאימות');
  };
}
function openDrawer(m, d) {
  state.openMachine = m.address;
  updateDrawer(m, d);
  $('drawerBackdrop').hidden = false;
  $('detailDrawer').classList.add('open');
  $('detailDrawer').setAttribute('aria-hidden', 'false');
  $('closeDrawer').focus();
}
function closeDrawer() {
  state.openMachine = null;
  $('drawerBackdrop').hidden = true;
  $('detailDrawer').classList.remove('open');
  $('detailDrawer').setAttribute('aria-hidden', 'true');
}
function resetFilters() {
  state.selectedCategory = null; state.filter = 'all'; state.search = '';
  $('search').value = '';
  document.querySelectorAll('.filter').forEach(b => b.classList.toggle('active', b.dataset.filter === 'all'));
  render();
}
function updateClock() { setText('clock', new Date().toLocaleTimeString('he-IL', { hour12: false })); }
function closeMobileMenu() { document.querySelector('.sidebar').classList.remove('open'); $('mobileBackdrop').hidden = true; $('mobileMenu').setAttribute('aria-expanded', 'false'); }

$('refreshBtn').addEventListener('click', () => { refresh().then(() => toast('הנתונים נבדקו מחדש · זה לא מפעיל סריקת Ping')); });
$('demoBtn').addEventListener('click', () => { state.demo = !state.demo; render(); toast(state.demo ? 'הדגמה פעילה — אלה נתונים מדומים' : 'הדגמה כובתה'); });
$('clearCategory').addEventListener('click', () => { state.selectedCategory = null; render(); });
$('search').addEventListener('input', e => { state.search = e.target.value; renderMachines(derive()); });
document.querySelectorAll('.filter').forEach(btn => btn.addEventListener('click', () => {
  state.filter = btn.dataset.filter;
  document.querySelectorAll('.filter').forEach(b => b.classList.toggle('active', b === btn));
  renderMachines(derive());
}));
$('layoutToggle').addEventListener('click', () => { state.list = !state.list; renderMachines(derive()); });
$('resetFilters').addEventListener('click', resetFilters);
$('closeDrawer').addEventListener('click', closeDrawer);
$('drawerBackdrop').addEventListener('click', closeDrawer);
$('mobileMenu').addEventListener('click', () => {
  const opened = document.querySelector('.sidebar').classList.toggle('open');
  $('mobileBackdrop').hidden = !opened; $('mobileMenu').setAttribute('aria-expanded', String(opened));
});
$('mobileBackdrop').addEventListener('click', closeMobileMenu);
document.querySelectorAll('.side-menu a').forEach(a => a.addEventListener('click', closeMobileMenu));
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeDrawer(); closeMobileMenu(); }
  if (e.key === '/' && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
    e.preventDefault(); $('search').focus(); $('fleet').scrollIntoView({ behavior: 'smooth' });
  }
});
updateClock(); setInterval(updateClock, 1000);
refresh(); setInterval(refresh, POLL_MS);
